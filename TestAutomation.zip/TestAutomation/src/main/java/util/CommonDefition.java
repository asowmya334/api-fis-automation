package util;

public class CommonDefition {

    public void Test()
    {
        System.out.println("This is the system");

    }
}
