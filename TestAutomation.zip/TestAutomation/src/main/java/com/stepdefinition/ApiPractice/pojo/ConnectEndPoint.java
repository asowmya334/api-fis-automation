package com.stepdefinition.ApiPractice.pojo;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


import com.google.gson.JsonObject;
import com.googlecode.totallylazy.json.Json;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.minidev.json.JSONObject;

import java.io.File;
import java.util.HashMap;

public class ConnectEndPoint {

    public void calTest() throws JsonProcessingException {
        FileReader();
    }

    public void FileReader()
    {
        File ff = new File("C:\\Users\\HQ11DS\\Sowmya\\TestAutomation\\src\\main\\java\\com\\stepdefinition\\ApiPractice\\pojo\\test.json");
        String a = String.valueOf(ff);

        Response res = RestAssured.given().header("Content-Type" , "application/json").header("Accept","application/json")
                .when().body(a).log().all().post("https://restful-booker.herokuapp.com/booking").then().log().all().extract().response();


        JsonPath pp = new JsonPath(res.body().asString());
        System.out.println(pp.getString("booking.bookingdates.checkin"));

    }


    public void RequestWithMap()
    {
        HashMap<String,Object > test =  new HashMap<>();
        test.put("firstname","Sowmya");
        test.put("lastname","Ankegowda");
        test.put("totalprice","100");
        test.put("totalprice","true");
        test.put("additionalneeds","seeet");

        HashMap<String,String > test2 =  new HashMap<>();
        test2.put("checkin","22-5-2024");
        test2.put("checkout","23-5-2024");

        test.put("bookingdates",test2);

        Response res =  RestAssured.given().header("Contente-Type","Application/json").header("Accept","application/json")
                .when().body(test).log().all().post("https://restful-booker.herokuapp.com/booking")
                .then().log().all().extract().response();


    }

    public void TestJsonObject()
    {
        JsonObject obj =  new JsonObject();
        obj.addProperty("firstname","Sowmya");
        obj.addProperty("lastname","Ankegowda");
        obj.addProperty("totalprice","100");
        obj.addProperty("totalprice","true");
        obj.addProperty("additionalneeds","seeet");

        JsonObject bkDates =  new JsonObject();
        bkDates.addProperty("checkin","22-5-2024");
        bkDates.addProperty("checkout","23-5-2024");


        obj.add("bookingdates",bkDates);


        Response res =  RestAssured.given().header("Contente-Type","Application/json").header("Accept","application/json")
                .when().body(obj).log().all().post("https://restful-booker.herokuapp.com/booking")
                .then().log().all().extract().response();

        JsonPath pp = new JsonPath(res.body().asString());
        System.out.println(pp.getString("booking.bookingdates.checkin"));


    }


    public void test() throws JsonProcessingException {

        //using pojo class
        Books bk = new Books();
        bk.setFirstname("sowmya");
        bk.setLastname("Srikanth");
        bk.setTotalprice("100");
        bk.setDepositpaid("true");
        bk.setAdditionalneeds("addtion Needs");

        BookingDates date = new BookingDates();
        date.setCheckin("monday");
        date.setCheckout("webnesday");

        bk.setBookingdates(date);


        ObjectMapper mapper = new ObjectMapper();

       String a =  mapper.writeValueAsString(bk);

        Response res = (Response) RestAssured.given().header("Content-Type","application/json")
                .header("Accept","application/json").body(a)
                .when().log().all().post("https://restful-booker.herokuapp.com/booking")
                .then().log().all().extract();


        JsonPath pp = new JsonPath(res.body().asString());
        System.out.println(pp.getString("booking.bookingdates.checkin"));

        BooksResponse test = mapper.readValue(res.body().asString(),BooksResponse.class);

       System.out.println(test.getBookingid());
    }

}
