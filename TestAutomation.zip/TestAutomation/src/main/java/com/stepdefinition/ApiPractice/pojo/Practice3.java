package com.stepdefinition.ApiPractice.pojo;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Practice3 {

    public void CallPractice3() {
        CountTheNumberOfString();

    }

    public void Test()
    {
        List<Integer>  test =  Arrays.asList(10,25,64,19,36);


        test.stream().filter(s -> s% 2 == 0).collect(Collectors.toList());
        test.stream().map(s -> s + "").filter(s -> s.startsWith("1"));

        Set<Integer> test1 = new HashSet<>();

                test.stream().filter(s -> test.add(s));




    }






    public void CountTheNumberOfString() {
        String a = "thhis is java program";

        Map<String, Long> test = Arrays.stream(a.split(" "))
                .map(String::toLowerCase)
                .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

        System.out.println(test);

    }






    public void NumPrime() {
        int num = 15;

        System.out.println(1);

        for (int i = 2; i < num; i++) {

            if (CheckPrime(i) == true) {
                System.out.println(i);
            }


        }
    }

    public boolean CheckPrime(int num) {
        boolean flag = true;

        for (int i = 2; i <= num; i++) {
            if (num % i == 0) {
                flag = false;


            } else {
                flag = true;
            }

        }

        return flag;
    }


    public void TotalSum() {

        List<Integer> arr = Arrays.asList(10, 65, 95, 35);

        arr.stream().mapToInt(Integer::intValue).sum();


    }


    public void FibbomnacciSeries() {
        int num = 5;
        int num1 = 0;
        int num2 = 1;
        int num3;

        System.out.println(num1);
        System.out.println(num2);
        for (int i = 1; i <= num; i++) {

            num3 = num1 + num2;
            num1 = num2;
            num2 = num3;

            System.out.println(num3);


        }


    }


    public void PrintPyramid() {
        int num = 2;
        int x = 2;
        int y = 0;

        for (int i = 0; i <= num; i++) {

            for (int j = 1; j <= i; j++) {
                System.out.println(y + "\t");
                y = y + x;


            }
            System.out.println("");


        }


    }


    public void Factorial() {
        int num = 5;
        int sum = 1;

        for (int i = 1; i <= num; i++) {
            sum = sum * i;
        }

        System.out.println(sum);


    }


    public void Pallidrome() {
        String a = "Sowmya";
        String rev = "";

        for (int i = 0; i < a.length(); i++) {
            String b = String.valueOf(a.charAt(i));
            rev = b + rev;

        }

        if (rev == a) {
            System.out.println("String is a pallidrome");
        } else
            System.out.println("Not a pallidrome");

    }


    public void LeapYear() {
        int year = 2025;
        if ((year % 400 == 0) || (year % 4 == 0) && (year % 100 != 0)) {
            System.out.println("this is a leap year");
        } else {
            System.out.println("this is not a leap year");
        }


    }


    public void ListOfEven() {
        int num = 15;
        for (int i = 2; i <= 15; i++) {
            if (i % 2 == 0) {
                System.out.println(i);
            }


        }


    }


    public void MapExample() {
        HashMap<String, Integer> test = new HashMap<>();

        test.put("Orange", 345);
        test.put("red", 456);
        test.put("black", 565);
        test.put("brown", 347);
        test.put("white", 122);

        for (Map.Entry<String, Integer> ll : test.entrySet()) {

            int val = ll.getValue();
            System.out.println(val * 125);

        }

        Iterator<Map.Entry<String, Integer>> nn = test.entrySet().iterator();

        while (nn.hasNext()) {
            int val = nn.next().getValue();
            System.out.println(val * 500);
        }


    }


    public void ListExample() {
        List<String> test = new ArrayList<>();

        test.add("Organige");
        test.add("yellow");
        test.add("Black");
        test.add("Brown");
        test.add("Green");
        test.add("Red");

        for (String nn : test) {

            System.out.println(nn);

        }

        Iterator<String> tt = test.iterator();

        while (tt.hasNext()) {
            System.out.println(tt.next() + "Test");

        }


    }
}
