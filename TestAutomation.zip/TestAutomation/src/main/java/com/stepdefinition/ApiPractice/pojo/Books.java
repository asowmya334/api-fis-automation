package com.stepdefinition.ApiPractice.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Books {
    private String firstname;
    private String lastname;
    private String totalprice;
    private String depositpaid;
    private String additionalneeds;
    private BookingDates bookingdates;
}
