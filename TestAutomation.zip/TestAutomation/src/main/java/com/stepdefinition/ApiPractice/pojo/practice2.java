package com.stepdefinition.ApiPractice.pojo;

public class practice2 extends practice1 {

    public static void main()
    {
        practice2 pr =  new practice2();
        pr.Test1();
    }

}
