package com.stepdefinition.ApiPractice.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookingDates {
    private String checkin;
    private String checkout;
}
