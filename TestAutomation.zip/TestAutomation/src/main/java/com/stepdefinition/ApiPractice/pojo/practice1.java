package com.stepdefinition.ApiPractice.pojo;

public class practice1 {

    public void Test1()
    {
        System.out.println("Test1");

    }

    public void Test2()
    {
        System.out.println("Test2");

    }

    public void Test3()
    {
        System.out.println("Test3");

    }


}
