package com.stepdefinition.ApiPractice.pojo;

import cucumber.api.java.eo.Se;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BooksResponse {
private int bookingid;
private Books booking;
}
