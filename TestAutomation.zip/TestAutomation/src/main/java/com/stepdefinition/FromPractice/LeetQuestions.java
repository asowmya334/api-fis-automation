package com.stepdefinition.FromPractice;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class LeetQuestions {


    //Given two strings ransomNote and magazine, return true if
    // ransomNote can be constructed by using the letters from magazine and false otherwise.
    //Example 1:
    //
    //Input: ransomNote = "a", magazine = "b"
    //Output: false
    //Example 2:
    //
    //Input: ransomNote = "aa", magazine = "ab"
    //Output: false
    //Example 3:
    //
    //Input: ransomNote = "aa", magazine = "aab"
    //Output: true
    //********************************************************************************************************
    //Given two strings s and t, determine if they are isomorphic.
    //
    //Two strings s and t are isomorphic if the characters in s can be replaced to get t.
    //
    //All occurrences of a character must be replaced with another character while preserving the order of characters. No two characters may map to the same character, but a character may map to itself.
    //
    //
    //
    //Example 1:
    //
    //Input: s = "egg", t = "add"
    //
    //Output: true
    //
    //Explanation:
    //
    //The strings s and t can be made identical by:
    //
    //Mapping 'e' to 'a'.
    //Mapping 'g' to 'd'.
    //Example 2:
    //
    //Input: s = "foo", t = "bar"
    //
    //Output: false
    //
    //Explanation:
    //
    //The strings s and t can not be made identical as 'o' needs to be mapped to both 'a' and 'r'.
    //
    //Example 3:
    //
    //Input: s = "paper", t = "title"
    //
    //Output: true
    //*******************************************************************************************88
    //Given a pattern and a string s, find if s follows the same pattern.
    //Example 1:
    //
    //Input: pattern = "abba", s = "dog cat cat dog"
    //
    //Output: true
    //
    //Explanation:
    //
    //The bijection can be established as:
    //
    //'a' maps to "dog".
    //'b' maps to "cat".
    //Example 2:
    //
    //Input: pattern = "abba", s = "dog cat cat fish"
    //
    //Output: false
    //
    //Example 3:
    //
    //Input: pattern = "aaaa", s = "dog cat cat dog"
    //
    //Output: false

    public void CallLeet() {
     WordPattern();

        System.out.println("sowmya");

    }

    public void WordPattern() {
        boolean flag = false;
        String pattern = "abba", s = "dog cat cat fish";
        char[] test = s.toCharArray();

        HashMap<Character, String> mapP = new HashMap<>();
        HashMap<Character, String> mapS = new HashMap<>();

        for (int i = 0; i < pattern.length(); i++) {
            char charP = pattern.charAt(i);
            String charS = String.valueOf(test[i]);

            if (!mapP.containsKey(charP)) {
                if (mapP.get(charP) != charS) {
                    flag = true;
                }
            } else {
                mapP.put(charP, charS);
            }

            if (!mapS.containsKey(charS)) {
                if (mapS.get(charS) != String.valueOf(charP)) {
                    flag = true;
                }
            } else {
                mapP.put(charP, charS);
            }


        }

    System.out.println(flag);
    }


    public boolean isIsomorphictest() {
        String s = "foo", t = "bar";
        if (s.length() != t.length()) {
            return false;
        }

        Map<Character, Character> mapST = new HashMap<>();
        Map<Character, Character> mapTS = new HashMap<>();

        for (int i = 0; i < s.length(); i++) {
            char charS = s.charAt(i);
            char charT = t.charAt(i);

            if (mapST.containsKey(charS)) {
                if (mapST.get(charS) != charT) {
                    return false;
                }
            } else {
                mapST.put(charS, charT);
            }

            if (mapTS.containsKey(charT)) {
                if (mapTS.get(charT) != charS) {
                    return false;
                }
            } else {
                mapTS.put(charT, charS);
            }
        }

        return true;
    }

    public void Isomorphic() {

        String e = "bbbaaaba", t = "aaabbbba";


        Map<Character, Long> test = e.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));
        List<Long> tt = new ArrayList<>();
        for (Map.Entry<Character, Long> nn : test.entrySet()) {
            tt.add(nn.getValue());

        }

        Map<Character, Long> teste = t.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));
        List<Long> ss = new ArrayList<>();
        for (Map.Entry<Character, Long> nn1 : teste.entrySet()) {
            ss.add(nn1.getValue());

        }

        Collections.sort(ss);
        System.out.println(ss);
        Collections.sort(tt);
        System.out.println(tt);

        if (ss.containsAll(tt)) {
            System.out.println("Isomorphic");
        } else {
            System.out.println("not a isomorphic");
        }


    }

    public void Test() {
        String ransomNote = "bg", magazine = "efjbdfbdgfjhhaiigfhbaejahgfbbgbjagbddfgdiaigdadhcfcj";
        boolean flag = true;
        Map<Character, Long> test = magazine.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));

        for (char c : ransomNote.toCharArray()) {

            if (!test.containsKey(c) || test.get(c) == 0) {
                flag = false;
            }
            test.put(c, test.get(c) - 1);
        }

        System.out.println(flag);
    }


}
