package com.stepdefinition.FromPractice;

import java.util.Arrays;

public class Stringbuilder {
    public void StringbuilderTest()
    {
        PracticeStringBuilder();
    }

    public void PracticeStringBuilder()
    {
        String input = "!4@T#6S%1E*9T";

        StringBuilder digit = new StringBuilder();
        StringBuilder alphabets = new StringBuilder();


        char[] inputs = input.toCharArray();

        for (char test : inputs) {
            if(Character.isDigit(test))
            {
                digit.append(test);
            } else if (Character.isAlphabetic(test)) {
                alphabets.append(test);

            }

        }


        System.out.println(digit);
        System.out.println(alphabets);
        Arrays.sort(digit.chars().toArray());
        System.out.println(digit);

        //Appende word

        StringBuilder b = new StringBuilder(input);
        b.append("World");

        System.out.println(b);
        //insert the string in the middle

        StringBuilder sb = new StringBuilder("Hello World");
        sb.insert(6,"Beautiful");

        System.out.println(sb);

    }


}
