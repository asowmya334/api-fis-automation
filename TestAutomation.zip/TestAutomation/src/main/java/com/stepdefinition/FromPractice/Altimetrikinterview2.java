package com.stepdefinition.FromPractice;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Altimetrikinterview2 {

    public void TestCall() {
        checkDuplicatesAndREverseArray();
    }

    








    public void checkDuplicatesAndREverseArray()
    {
        String s = "My name is sowmya";
        String rev = "";

              System.out.println("Sowmya");
        for(int i = 0 ; i < s.length() ; i++)
        {
           if(CheckCharacter(rev,s.charAt(i)) == false)
           {
               rev  =  s.charAt(i) + rev;
               
           }



        }
        System.out.println(rev);




    }

    public boolean CheckCharacter(String e , char c)
    {
        CharSequence charSequenceAlt = String.valueOf(c);
        if(e.contains(charSequenceAlt))
        {
            return true;
        }
       return  false;

    }

    public void NthLargest() {
        int a[] = {10, 25, 63, 75, 96, 95, 354};
       Integer c[]  = Arrays.stream(a).mapToObj(s -> Integer.valueOf(s)).toArray(Integer[]::new);

       Arrays.sort(c,Collections.reverseOrder());
       System.out.println(Arrays.toString(c));
       System.out.println(c[c.length - 3]);

    }


    public void FindCount() {
        String a = "This is somwya";

        HashMap<Character, Long> b = a.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));

        System.out.println(b);

        Optional<Map.Entry<Character, Long>> maxEntry = b.entrySet().stream().max(Map.Entry.comparingByValue());
        System.out.println(maxEntry);


        HashMap<Character, Integer> s1 = new HashMap<>();
        int count = 1;

        for (int i = 0; i < a.length(); i++) {
            if (s1.containsKey(a.charAt(i))) {
                s1.put(a.charAt(i), s1.get(a.charAt(i) + 1));


            } else {
                s1.put(a.charAt(i), 1);
            }
        }

        System.out.println(s1);

    }

    public void EvenOrODD() {
        int num = 10;


        if (num % 2 == 0) ;

        {
            System.out.println("The number is even");
        }


    }

    public void Fibbonaci() {
        int num = 5;
        int num1 = 0;
        int num2 = 1;
        int num3;

        System.out.println(num1);
        System.out.println(num2);

        for (int i = 2; i <= num; i++) {
            num3 = num1 + num2;
            System.out.println(num3);
            num1 = num2;
            num2 = num3;
        }


    }


    public void Factorial() {
        int num = 5;
        int res = 1;
        for (int i = 1; i <= num; i++) {

            res = res * i;


        }

        System.out.println(res);


    }


    public void CheckPrimeNumber() {
        int num = 15;
        boolean flag = false;

        for (int i = 2; i < num - 1; i++) {
            if (num % i == 0) ;
            {
                flag = true;
            }
        }
        if (flag == false) {
            System.out.println("It is a prime");
        } else {
            System.out.println("It  is not  a prime");
        }
    }


    public void FindLargest() {
        int a[] = {10, 25, 96, 35, 75, 95, 45, 36};
        int largest = a[0];

        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest) {
                largest = a[i];
            }

        }
        System.out.println(largest);

    }

    public void SecondLargestNumber() {
        int a[] = {10, 25, 63, 75, 96, 95, 354};
        int largest = a[0];
        int secondLargest = a[0];

        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest) {
                secondLargest = largest;
                largest = a[i];
            } else if (a[i] != largest && a[i] > secondLargest) {
                secondLargest = a[i];
            }

        }

        System.out.println(secondLargest);
    }

}
