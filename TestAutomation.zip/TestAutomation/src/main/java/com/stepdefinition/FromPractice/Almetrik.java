package com.stepdefinition.FromPractice;

import java.util.ArrayList;
import java.util.List;

public class Almetrik {

    public void TestAltmer() {
        MinsubArray();
    }

    public void MinsubArray()
    {
        int[] num = {2,3,1,2,4,3};
        int target = 7;
        int sum = 0;
        List<List<Integer>> test = new ArrayList<>();

        for(int i = 0 ; i < num.length ; i++)
        {
            sum = sum + num[i] ;
            if(sum >= target)
            {
                test.add(SubArray(num,target,i));
            }
        }

        System.out.println(test.size());
        System.out.println(test);




    }
    public List<Integer> SubArray(int[] num,int target , int start)
    {
        List<Integer> test = new ArrayList<>();
        int sum = 0;
        for(int i = 1 ; i < num.length ; i++)
        {
            sum = sum + num[i] ;
            if(sum >= target)
            {
                test.add(Integer.valueOf(num[i]));
            }
        }
        return test;
    }





    public void TestSet2()
    {
        int[] a = {-1,0,1,2,-1,-4};
        int sum = 0;
        for(int i = 0 ; i < a.length ; i++)
        {
            for(int j = i+1 ; j < a.length ; j++ )
            {
              for(int k = 0 ; k < a.length ; k++)
              {
               // a[i]


              }

            }


        }




    }



    public void GetConsectiveSun() {
        int[] a = {2, 3, 4};
        int num = 6;
        int sum;

        for (int i = 0; i < a.length; i++) {

            for (int j = i + 1; j < a.length; j++) {
                sum = a[i] + a[j];
                if (sum == num) {
                    System.out.println(i + 1);
                    System.out.println(j + 1);

                } else {
                    break;
                }

            }
        }

    }

    public void GetSum() {
        int[] a = {2, 3, 4};
        int num = 6;
        int sum;

        for (int i = 0; i < a.length; i++) {

            for (int j = i + 1; j < a.length; j++) {
                sum = a[i] + a[j];
                if (sum == num) {
                    System.out.println(i + 1);
                    System.out.println(j + 1);

                }

            }
        }

    }


}
