package com.stepdefinition.FromPractice;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class fis_interview {
    public void RunTest() {

        SortArrayUisngArray();
    }

    public void SortArrayUisngArray() {

        int[] originalArray = {10, 25, 96, 45, 36, 74, 56};
        int temp ;

        for(int i = 0 ; i < originalArray.length ; i++)
        {
            for(int j = i+1 ; j < originalArray.length ; j++)
            {
                if(originalArray[i] > originalArray[j])
                {
                    temp = originalArray[i];
                    originalArray[i] = originalArray[j];
                    originalArray[j] = temp;
                }

            }
        }
        System.out.println(Arrays.toString(originalArray));


    }

    public void OccuranceOfEachString() {

        String a = "This is sowmya";

        Map<Character, Long> c = a.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));

        System.out.println(c);


    }


    public void ArrayAddition2() {

        int[] originalArray = {10, 25, 96, 45, 36, 74, 56, 12, 34, 78, 90, 11, 22, 33, 44};
        List<int[]> test = new ArrayList<>();

        int start = 0;
        int end;
        for (int i = 0; i < originalArray.length; i++) {
            start = i;
            end = i + 5;
            test.add(SplitArray(originalArray, start, end));
            i = end - 1;
        }
        for (int[] b : test) {
            System.out.println(Arrays.toString(b));

        }

    }

    public int[] SplitArray(int[] a, int start, int end) {
        int[] n = new int[5];
        int index = 0;
        for (int j = start; j < end; j++) {
            n[index++] = a[j];

        }
        return n;
    }


    public void ArrayAddtion() {
        int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 2};
        int count = 0;
        int res = 0;
        int start = 0;
        int end = 0;
        for (int i = 0; i < a.length; i++) {
            if (count == 0) {
                start = i;
                end = i + 1;
                res = GetSum(a, start, end) + res;
                count = count + 1;
            } else {
                start = i;
                end = i + 2;
                res = GetSum(a, start, end) + res;
                count = 0;
            }
            i = end;
        }
        System.out.println(res);
    }

    public int GetSum(int[] a, int start, int end) {
        String res = "";
        for (int i = start; i <= end; i++) {
            res = res + String.valueOf(a[i]);
        }
        System.out.println(res);
        return Integer.valueOf(res);
    }


    public void shiftZerro() {
        int[] arr = {1, 5, 4, 1, 8, 1, 1};
        int[] outputArr = new int[arr.length];
        int index = 0;
        int total = (int) Arrays.stream(arr).filter(n -> n == 1).count();
        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] != 1) {
                outputArr[index++] = arr[i];
            }
        }
        System.out.println(index);
        for (int i = index + 1; i <= arr.length; i++) {
            outputArr[index++] = 1;
        }
        System.out.println(Arrays.toString(outputArr));
    }

    //write program to shift all 0 to left hand side without changing the order from input [0, 5, 4, 0, 8, 0, 0]
    public void MoveZeroAndDoNotChangeOrder() {
        int[] e = {0, 5, 4, 0, 8, 0, 0};
        int num = 0;
        int[] output = new int[e.length - 1];
        int index = 0;

        for (int i = 0; i < e.length; i++) {
            if (e[i] != num) {
                output[index++] = e[i];
            }


        }

        System.out.println(Arrays.toString(output));

    }


    public void Test1() {
        String a = "This is a String";
        String rev = "";

        String[] b = a.split(" ");

        for (int j = 0; j < b.length; j++) {
            String e = b[j];
            for (int i = 0; i < e.length(); i++) {
                int start = i;
                int end = start + 2;
                if (e.length() > 2) {
                    String c = e.substring(start, end);

                    rev = rev + ReveseGivenString(c);
                    i = end - 1;
                } else {
                    String c = b[start];
                    rev = rev + ReveseGivenString(c);
                }
            }

        }


        System.out.println(rev);
    }

    public String ReveseGivenString(String a) {
        String rev = "";
        for (int i = 0; i < a.length(); i++) {
            rev = a.charAt(i) + rev;
        }
        return rev;
    }


    public void FindnthPrice() {
        int[] a = {10, 25, 96, 45, 36, 74, 56};


        int[] c = Arrays.stream(a).boxed().sorted(Comparator.reverseOrder()).mapToInt(Integer::intValue).toArray();
        int[] d = Arrays.stream(a).boxed().sorted(Comparator.reverseOrder()).mapToInt(Integer::intValue).toArray();

        Arrays.stream(a).boxed().sorted(Comparator.reverseOrder()).mapToInt(Integer::intValue).toArray();
        int[] e = Arrays.stream(a).boxed().sorted(Comparator.reverseOrder()).mapToInt(Integer::intValue).toArray();

        Arrays.stream(a).boxed().sorted(Comparator.reverseOrder()).mapToInt(Integer::intValue).toArray();
        System.out.println(Arrays.toString(a));
        System.out.println(Arrays.toString(c));

        System.out.println(c[3 - 1]);


    }

    public void CheckPrimeNumber() {
        int c = 24;
        boolean flag = false;

        for (int i = 2; i < c - 1; i++) {
            if (c / i == 0) {
                flag = true;
            }

        }


        if (flag == true) {
            System.out.println("It isnot  a prime");
        } else {
            System.out.println("It is a  prime");
        }


    }


    public void FindLargest() {
        int[] a = {10, 25, 96, 45, 36, 74, 56};
        int largest = a[0];

        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest) {
                largest = a[i];
            }

        }

        System.out.println(largest);


    }

    public void SecondLargestElement() {
        int[] a = {10, 25, 96, 45, 36, 74, 56};
        int largest = a[0];
        int secondLargest = a[0];
        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest) {
                secondLargest = largest;
                largest = a[i];
            } else if (a[i] != largest && a[i] > secondLargest) {
                secondLargest = a[i];
            }
        }
        System.out.println(largest);
        System.out.println(secondLargest);
    }

public void Test()
{
    int[] a = {10,59,63,48,75};
    int largest = a[0];
    int secondLargest = a[0];

    for(int i = 0 ; i < a.length ; i++)
    {
        if(a[i] > largest)
        {
            secondLargest = largest;
            largest =a[i];
        } else if (a[i] != largest && a[i]> secondLargest) {
            secondLargest = a[i];
        }
    }


}


    public void Rotate() {
        int[] b = {1, 2, 3, 4, 5, 6, 7};


        int[] c = new int[b.length];

        for (int i = 0; i < b.length; i++) {

            b = Test(b);
            System.out.println(Arrays.toString(b));

        }


    }

    public int[] Test(int[] a) {
        int[] c = new int[a.length];
        int k = 0;
        int leng = a.length - 1;

        c[k] = a[leng];
        for (int i = 0; i < a.length - 1; i++) {
            k++;
            c[k] = a[i];

        }
        return c;

    }


    public void GetMajorityelement() {
        int[] nums = {1, 1, 1, 2, 2, 3};
        List<Integer> nn = new ArrayList<>();

        Optional<Map.Entry<Integer, Long>> test = Arrays.stream(nums).boxed()
                .collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting())).entrySet().stream().max(Map.Entry.comparingByValue());


        test.ifPresent(entry -> System.out.println("Max value: " + entry.getKey() + " occurs " + entry.getValue() + " times"));


    }

    public void RemovedDuplicates2() {
        int[] nums = {1, 1, 1, 2, 2, 3};
        List<Integer> nn = new ArrayList<>();

        Map<Integer, Long> test = Arrays.stream(nums).boxed()
                .collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));


        for (Map.Entry<Integer, Long> tt : test.entrySet()) {
            if (tt.getValue() >= 2) {
                for (int i = 0; i < 2; i++) {
                    nn.add(tt.getKey());
                }

            } else {
                nn.add(tt.getKey());
            }

        }

        System.out.println(nn);
        System.out.println(nn.size());
    }


    public void RemoveDuplicateElements() {
        int[] nums = {1, 1, 2};

        int[] c = Arrays.stream(nums).distinct().toArray();


    }


    public void RemoveElemet() {
        int[] nums = {3, 2, 2, 3};
        int val = 3;
        int[] expectedNums = new int[nums.length];
        int k = 0;

        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != val) {
                expectedNums[k] = nums[i];
                k++;
            }

        }

        System.out.println(Arrays.toString(expectedNums));


    }


    //Mege Sorted Arrray
    public void MergeSortedArray() {
        int[] a = {1, 2, 3, 0, 0, 0};
        int num1 = 3;
        int[] b = {2, 5, 6};
        int num2 = 3;
        int[] cd = new int[num1 + num2 - 1];
        cd = merge(a, num1, b, num2);
        System.out.println(Arrays.toString(cd));
        int[] e = IntStream.concat(Arrays.stream(a, 0, num1), Arrays.stream(b, 0, num2)).sorted().toArray();
        System.out.println(Arrays.toString(e));


    }

    public int[] merge(int[] a, int num, int[] b, int num2) {
        int[] c = new int[num + num2];
        int k = 0;
        for (int i = 0; i < c.length; i++) {
            if (i < num) {
                c[i] = a[i];
            }
        }

        for (int j = num; j < c.length; j++) {

            if (k < num2) {
                c[j] = b[k];
                k++;
            }
        }
        return Arrays.stream(c).sorted().toArray();
    }


}
