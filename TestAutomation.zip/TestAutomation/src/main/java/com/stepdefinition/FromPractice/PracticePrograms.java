package com.stepdefinition.FromPractice;

//Given an unsorted array of integers, find the third largest number in the array. If the array has less than 3 distinct numbers
// return the largest number ?  Example
// Input:
// arr=[2,4,1,5,3,6]
// Output:
//--------------------
//Given an array Of Strings, group the strinbgs that are anagrams of each other.
//  Example:
//  Input:
//  arr=["eat","tea","tan","ate","nat","bat"]
//  Output:
//  [["eat,"tea","ate"],["tan","nat"],["bat"]]
//  Explaination: The group of anagrams are ["eat,"tea","ate"],["tan","nat"] and ["bat"]
//------------------------------------------------------------------------------
//Given an array of integers, find the largest number that does not have any duplicates in an array.
//  Example:
//  Input:
//  arr=[4,3,2,7,3,4,8]
//  Output:
//  8
//  Explaination: The unique numbers are [2,7,8] and the largest among them is   8
//-----------------------------------------------------------------------
//1. Write a program to find duplicate elements in a string array.
//-----------------------------------------------------------------------------
//write program to shift all 0 to left hand side without changing the order from input [0, 5, 4, 0, 8, 0, 0]
//------------------------------------------------------------------------------------------------
//Concat first 2 num and 3 nums and find the sum of them
//int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 2};
//12+345+67+891
//-------------------------------------------------------------------------------------------
//Replace and Reverse
// String a = "sowmya Ankegowda";
//Output = osmway naekogdwa;
//--------------------------------------------------------------------------------------------
//program to sort an array - using stream , and with out using streams in ascednign order and descending order
//Reverse A string using string builder and without using string builder
//Find Largest and Second Largest
//Find the Nth Largest
//find the duplicate characters in a string
//Remove duplicate char from string
//String count of non-space chracter: Write a program to calculate the count of non-space characters in a string.
//Input: This is a string
//Output: 13
//Chek prime number
//Check leap year
//https://medium.com/@bhavin_thumar/top-java-coding-interview-questions-for-automation-tester-85550ab4d73c
// Java Program to Find Odd or Even number
//Factorial
//Fibbonacci
//Find the Index of the First Occurrence in a String
//---------------------------------------------------
//Example 1:
//
//Input: numbers = [2,7,11,15], target = 9
//Output: [1,2]
//Explanation: The sum of 2 and 7 is 9. Therefore, index1 = 1, index2 = 2. We return [1, 2].
//-------------------------------------------------------
//{0, -1, 2, -3, 1}
//Output: {{0, 1, 4}, {2, 3, 4}}

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PracticePrograms {
    public void CallPracticePrograms() {

        ArraySum();
        System.out.println("Sowmya");
    }

    public void ArraySum(){
        int[] a = {0, -1, 2, -3, 1};
        List<int[]> test = new ArrayList<>();

        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                for (int k = j + 1; k < a.length; k++) {
                    if (i != j && i != k && j != k) {
                        int sum = a[i] + a[j] + a[k];
                        if (sum == 0) {
                            int[] b = new int[3];  // Create a new array for each triplet
                            b[0] = a[i];
                            b[1] = a[j];
                            b[2] = a[k];
                            test.add(b);
                        }
                    }
                }
            }
        }

        System.out.println("Triplets that sum to zero:");
        for (int[] triplet : test) {
            System.out.println(Arrays.toString(triplet));
        }
    }


    public void sumOfTwoArray() {
        int[] numbers = {2, 7, 11, 15};
        int target = 9;
        int[] res = new int[2];
        int start = 0;

        for (int i = 0; i < numbers.length; i++) {
            for (int j = i + 1; j < numbers.length; j++) {
                if (numbers[i] + numbers[j] == target) {
                    res[start] = i;
                    res[start + 1] = j;
                }

            }
        }
        System.out.println(Arrays.toString(res));
    }


    public void CountnonSpaceCharacter() {
        String a = "This is a string";


        String c = a.replace(" ", "");

        Integer d = Math.toIntExact(c.chars().mapToObj(s -> (char) s).count());
        System.out.println(String.valueOf(d));

    }

    public void RemoveDuplicate() {
        String a = "My name is sowmya";
        String b = "";

        for (int i = 0; i < a.length(); i++) {
            String c = String.valueOf(a.charAt(i));
            if (!b.contains(c)) {
                b = c + b;
            }

        }
        System.out.println(a);
        System.out.println(b);

    }

    public void FindDuplicate() {

        String b = "MyNameIsSowmya";
        String c = "";

        for (int i = 0; i < b.length(); i++) {
            CharSequence e = String.valueOf(b.charAt(i));
            if (c.contains((e))) {
                System.out.println(b.charAt(i));
            } else {
                c = c + e;
            }
        }

    }


    public void duplicateChracters() {
        String a = "This is my name";


        Map<Character, Long> tt = a.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));

        System.out.println(tt);

        HashMap<Character, Integer> test = new HashMap<>();

        for (int i = 0; i < a.length(); i++) {
            if (test.containsKey(a.charAt(i))) {
                test.put(a.charAt(i), test.get(a.charAt(i)) + 1);
            } else {
                test.put(a.charAt(i), 1);
            }
        }

        System.out.println(test);
        Character[] c = {'a', 'e', 'i', 'o', 'u'};

        Iterator<Map.Entry<Character, Integer>> test1 = test.entrySet().iterator();

        for (int i = 0; i < c.length; i++)
            while (test1.hasNext()) {
                Character e = c[i];
                Character d = (Character) (Character) test1.next().getKey();
                if (String.valueOf(e).equalsIgnoreCase(String.valueOf(d))) {
                    System.out.println(test1.next().getKey());
                    System.out.println(test1.next().getValue());
                }
            }

    }


    public void SecondLargest() {
        int[] a = {25, 96, 78, 3, 5, 9, 6, 47, 88, 95, 32, 5, 9};
        int largest = a[0];
        int secondLargest = a[0];

        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest) {
                secondLargest = largest;
                largest = a[i];
            } else if (a[i] != largest && a[i] > secondLargest) {
                {
                    secondLargest = a[i];
                }

            }

        }
        System.out.println(Arrays.toString(a));
        System.out.println(largest);
        System.out.println(secondLargest);


        Integer[] d = Arrays.stream(a).boxed().sorted(Comparator.reverseOrder()).toArray(Integer[]::new);

        System.out.println(String.valueOf(d[1]));
        System.out.println(String.valueOf(d[3 - 1]));


    }

    public void ReverseArray() {
        String a = "This is my name";
        String rev = "";

        for (int i = 0; i < a.length(); i++) {
            rev = a.charAt(i) + rev;
        }

        System.out.println(rev);

        //uisng string builder

        StringBuilder buildr = new StringBuilder();
        buildr.append(a);
        buildr.reverse();

        System.out.println(buildr);

    }


    public void SortArray() {
        int[] a = {52, 45, 32, 64, 12, 87, 78, 98, 23, 7};
        int temp;

        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[i] > a[j]) {
                    temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }

        }

        System.out.println(Arrays.toString(a));

        //using Sterams

        Integer[] c = Arrays.stream(a).boxed().sorted().toArray(Integer[]::new);
        System.out.println(Arrays.toString(c));

        Integer[] d = Arrays.stream(a).boxed().sorted(Comparator.reverseOrder()).toArray(Integer[]::new);
        System.out.println(Arrays.toString(d));

    }

    public void ReplaceReverse() {
        String a = "sowmya Ankegowda";
        String[] b = a.split(" ");
        String rev = "";

        for (int i = 0; i < b.length; i++) {
            String c = b[i];
            for (int j = 0; j < c.length(); j++) {
                int start = j;
                int end = start + 2;
                if (end <= c.length()) {
                    String d = reverse(c.substring(j, end));
                    rev = d + rev;
                    j++;
                } else {
                    rev = c.charAt(start) + rev;
                }
            }

        }

        System.out.println(rev);

    }

    public String reverse(String c) {
        String rev = "";
        for (int i = 0; i < c.length(); i++) {
            rev = c.charAt(i) + rev;
        }
        return rev;
    }

    public void ArrayAddition() {
        int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 2};
        int start = 0;
        int end = 0;
        int count = 0;
        int res = 0;

        for (int i = 0; i < a.length; i++) {
            if (count == 0) {
                start = i;
                end = start + 1;
                if (end < a.length) {
                    res = res + ConcatTheNumber(start, end, a);
                }
                count = 1;
                end = end - 1;

            } else if (count == 1) {
                start = i;
                end = start + 3;
                if (end < a.length) {
                    res = res + ConcatTheNumber(start, end, a);
                }
                count = 0;
                end = end - 1;

            }


        }
        System.out.println(res);


    }

    public int ConcatTheNumber(int start, int end, int[] a) {
        String sum = String.valueOf(a[start]) + String.valueOf(a[end]);
        return Integer.valueOf(sum);

    }


    public void ShiftZero1() {
        int[] a = {1, 5, 4, 1, 8, 1, 1};
        int[] c = new int[a.length];
        int start = 0;

        int count = (int) Arrays.stream(a).filter(s -> s == 1).count();

        for (int i = 0; i < a.length; i++) {
            if (a[i] != 1) {
                c[start] = a[i];
                start++;
            }

        }

        for (int i = start + 1; i <= a.length; i++) {
            c[start] = 1;
            start++;
        }


        System.out.println(Arrays.toString(c));


    }

    public void shiftZerro() {
        int[] arr = {0, 5, 4, 0, 8, 0, 0};
        int[] outputArr = new int[arr.length - 1];
        int index = 0;
        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] != 0) {
                outputArr[index++] = arr[i];
            }
        }
        System.out.println(Arrays.toString(outputArr));
    }

    public void ShiftingZero() {
        int[] a = {0, 5, 4, 0, 8, 0, 0};
        int[] b = new int[a.length - 1];
        int start = 0;
        int end = 0;



        for (int i = 0; i < a.length; i++) {
            if (a[i] != 0) {
                b[start] = a[i];
                start++;
            }


        }
        System.out.println(Arrays.toString(b));

    }


    public void FindDuplicates() {
        int[] b = {4, 3, 2, 7, 3, 4, 8};

        for (int i = 0; i < b.length; i++) {
            for (int j = i + 1; j < b.length; j++) {
                if (b[i] == b[j]) ;
                {
                    System.out.println(b[i]);
                }
            }

        }

    }


    public void LargestDuplicate() {
        int[] b = {4, 3, 2, 7, 3, 4, 8};

        Optional<Integer> c = Arrays.stream(b).boxed().sorted().max(Comparator.naturalOrder());
        System.out.println(c);
    }


    public void anagrams() {
        String[] arr = {"eat", "tea", "tan", "ate", "nat", "bat"};
        HashMap<String, List<String>> test = new HashMap<>();
        List<List<String>> 0 = new ArrayList<>();

        for (String a : arr) {
            String sorted = a.chars().sorted().mapToObj(c -> String.valueOf((char) c))
                    .collect(Collectors.joining());
            if (!test.containsKey(sorted)) {
                test.put(sorted, new ArrayList<>());
            }
            test.get(sorted).add(a);
        }


        System.out.println(test.entrySet());

        Iterator<Map.Entry<String, List<String>>> test2 = test.entrySet().iterator();

        while (test2.hasNext()) {
            tt.add(test2.next().getValue());

        }

        System.out.println(tt);
    }


    public void ThirdLargestArray() {
        int[] a = {10, 56, 96, 87, 45, 2, 95, 96, 26, 63, 58};

        Integer[] b = Arrays.stream(a).boxed().sorted().distinct().toArray(Integer[]::new);

        Arrays.sort(b, Collections.reverseOrder());

        System.out.println(Arrays.toString(b));
        System.out.println(b[3 - 1]);

        Integer[] c = Arrays.stream(a).boxed().distinct().sorted().toArray(Integer[]::new);
        System.out.println(b[3 - 1]);
        if (Arrays.stream(c).count() > 3) {
            System.out.println(Arrays.stream(c).max(Comparator.naturalOrder()));
        }
    }


}
