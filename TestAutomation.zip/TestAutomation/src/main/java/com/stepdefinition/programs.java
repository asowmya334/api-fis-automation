package com.stepdefinition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class programs {
    //reverse a string



    public void ReverseString()
    {
        String a = "Sowmya";
        String rev =  null;
        char s[] = a.toCharArray();
        int d = a.length();
        for(int i = d-1  ; i >= 0 ; i--)
        {
            System.out.println(s[i]);
             rev = s[i] + rev ;

        }

        System.out.println(rev);
    }

    public void findLargest()
    {
        int arr[] = {100,56,77,255,74,14,};
        int findlarges = arr[0];

        for(int  i =  0 ; i < arr.length ; i++)
        {
            if(arr[i] > findlarges)
            {
                findlarges = arr[i];

            }
        }
        System.out.println(findlarges);
    }

    public void SecondLargest()
    {
        int[] arr = {100,522,123,444,41,57,111};
        int largest = arr[0];
        int secondLargest = arr[0];
        for(int i = 0 ; i < arr.length ; i++) {
            if (arr[i] > largest) {
                secondLargest = largest;
                largest = arr[i];
            } else if (arr[i] > secondLargest && arr[i] != largest) {
                secondLargest = arr[i];
            }
        }
        System.out.println(secondLargest);

    }

    public void CheckOccurance()
    {
        String a = "sowmyaa";
        int count = 0;
        char[] ab = a.toCharArray();

        HashMap<Character , Integer> test = new HashMap<>();

        for ( char c : ab) {
            
          if(test.containsKey(c))
            {
                count = test.get(c);
                test.put(c ,count+1 );

            }
          else
          {
              test.put(c,1);
          }

        }
        System.out.println(test);








    }

    public void Test()
    {
        String[] arr = {"This" , "Test","Test2" ,"Test3","Test4","Test2","Test5"};
        String word1 = "Test";
        String word2 = "Test5";
        int count;
        String word;

        for(int i = 0 ; i < arr.length-1  ; i++  )
        {
            if(arr[i] == word1)
            {
                count = 1;
                word = arr[i];
                for(int j = i+1 ; j <= arr.length -1 ; j++)
                {
                    word = arr[j];
                    if(arr[j] != word2 )
                    {

                        count = count+1;

                    }

                }
                System.out.println("count");
                System.out.println(count);
                break;
            }


        }







    }

}
