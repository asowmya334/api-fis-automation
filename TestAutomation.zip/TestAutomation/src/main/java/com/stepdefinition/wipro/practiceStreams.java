package com.stepdefinition.wipro;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


public class practiceStreams {

    public void Test() {
        mergeArray();

    }

    //Merge Sorted Array
    public void mergeArray() {
        int[] nums1 = {1};
        int[] nums2 = {};
        int m = 1;
        int n = 0;
        int[] num3 = new int[m + n];
        int index = 0;

        for (int i = 0; i < m; i++) {
            num3[i] = nums1[i];
            index = i - 1;


        }

        for (int j = 0; j < num3.length; j++) {
            index = 3 + j;
            if(j< nums2.length)
            {
                num3[index] = nums2[j];
            }

        }


        System.out.println(Arrays.toString(num3));


    }


    public void ContainsDuplicate() {
        int[] nums = {1, 2, 3, 1};


        int test = (int) Arrays.stream(nums).boxed().collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting())).entrySet()
                .stream().filter(n -> n.getValue() > 1).count();

        if (test > 0) {

        }


    }

    public void ReturnIndexOfTarget() {

        int[] num = {1, 3, 5, 6};
        int target = 7;
        int index = 0;

        for (int i = 0; i < num.length; i++) {
            if (num[i] == target) {
                index = i;
            }
        }

        if (index == 0) {
            for (int i = 0; i < num.length; i++) {
                if (num[i] > target) {
                    System.out.println("test");
                    System.out.println(i);
                    index = i;
                } else {
                    index = num.length - 1;
                }
            }
        }


    }


    //Given two strings needle and haystack, return the index of the first occurrence of needle in haystack, or -1 if needle is not part of haystack.

    public void test5() {
        String haystack = "sadbutsad";
        String needle = "ad";

        int index = 0;

        index = haystack.indexOf(needle);
        System.out.println(index);


    }

    //write program to shift all 0 to left hand side without changing the order from input [0, 5, 4, 0, 8, 0, 0]

    public void Pallidrome() {
        int x = -121;
        String res = "";

        String c = String.valueOf(x);

        for (int i = 0; i < c.length(); i++) {
            res = c.charAt(i) + res;


        }

        System.out.println(res);
        System.out.println(x);


        if (String.valueOf(x).equalsIgnoreCase(res)) {
            System.out.println("ture");
        } else {
            System.out.println("false");
        }


    }


    public void LongestPrefix2() {
        String[] strs = {"flower", "flow", "flight"};

        Arrays.sort(strs);
        System.out.println(Arrays.toString(strs));
        String s1 = strs[0];
        String s2 = strs[strs.length - 1];
        String c;
        String res = "";
        int idx = 0;

        for (String b : strs) {
            if (b != s1) {
                for (int i = 1; i < b.length(); i++) {
                    String d = b.substring(0, i);
                    if (s1.startsWith(b.substring(0, i))) {
                        c = b.substring(0, i);
                        System.out.println(c);
                        res = res + c;
                    }


                }

            }

        }


    }


    public void LongestPrefix() {
        String[] strs = {"flower", "flow", "flight", "sweet"};

        Arrays.sort(strs);
        System.out.println(Arrays.toString(strs));
        String s1 = strs[0];
        String s2 = strs[strs.length - 1];
        int idx = 0;
        while (idx < s1.length() && idx < s2.length()) {
            if (s1.charAt(idx) == s2.charAt(idx)) {
                idx++;
            } else {
                break;
            }
        }
        System.out.println(s1.substring(0, idx));

    }


    public void NumSum() {
        int[] num = {2, 7, 11, 15};
        int target = 9;
        int sum = 0;

        for (int i = 0; i < num.length; i++) {
            for (int j = i + 1; j < num.length; j++) {
                sum = num[i] + num[j];
                if (sum == target) {
                    System.out.println(num[i]);
                    System.out.println(num[j]);
                }


            }


        }


    }


    public void shiftZerro() {
        int[] arr = {1, 5, 4, 1, 8, 1, 1};
        int[] outputArr = new int[arr.length];
        int index = 0;
        int total = (int) Arrays.stream(arr).filter(n -> n == 1).count();
        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] != 1) {
                outputArr[index++] = arr[i];
            }
        }

        System.out.println(index);
        for (int i = index + 1; i <= arr.length; i++) {
            outputArr[index++] = 1;
        }
        System.out.println(Arrays.toString(outputArr));

    }


    public void test2() {

        String a = "this is a java prog and learn a prog";
        String b[] = a.split(" ");
        Arrays.stream(b).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting())).entrySet()
                .stream().forEach(s -> System.out.println(s.getKey() + " : " + s.getValue()));


        List<Integer> tt = Arrays.asList(10, 26, 55, 15, 36, 77, 10, 55);


        tt.stream().collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));
    }

    //Given a list of integers, find out all the even numbers that exist in the list using Stream functions?
    public void EvenNumerStreams() {
        String input = "Java articles are Awesome";

        System.out.println(input.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), Collectors.counting())));

        input.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()))
                .entrySet().stream().filter(s -> s.getValue() == 1).forEach(s -> System.out.println(s.getKey() + ":" + s.getValue()));


        input.chars().mapToObj(s -> (char) s)
                .collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()))
                .entrySet().stream().filter(s -> s.getKey() > 1)
                .forEach(s -> System.out.println(s.getKey() + ":" + s.getValue()));


        System.out.println("one");
        List<Integer> tt = Arrays.asList(10, 26, 55, 15, 36, 77, 10, 55);


        tt.stream().collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));


        Set<Integer> nn = tt.stream().collect(Collectors.toCollection(HashSet::new));
        System.out.println(nn);


        tt.stream().filter(n -> n % 2 == 0).forEach(System.out::println);

        System.out.println("two");
        //number start with 1
        tt.stream().map(s -> s + " ").filter(n -> n.startsWith("1")).forEach(System.out::println);

        System.out.println("three");
        // How to find duplicate elements in a given integers list in java using Stream functions?
        Set<Integer> set = new HashSet<>();
        tt.stream().filter(n -> !set.add(n)).forEach(System.out::println);

        System.out.println("find first element");
        tt.stream().findFirst().ifPresent(System.out::println);

        System.out.println(tt.stream().count());

        System.out.println("Maximum");
        System.out.println(tt.stream().max(Integer::compare));

        // tt.stream().collect(Collectors.groupingBy())
    }


}
