package com.stepdefinition;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateUser2 {

    private String Name;
    private String job;

}
