package com.stepdefinition;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stepdefinition.ApiPractice.pojo.ConnectEndPoint;
import com.stepdefinition.ApiPractice.pojo.Practice3;
import com.stepdefinition.ApiPractice.pojo.practice2;
import com.stepdefinition.Practice2.Day1;
import com.stepdefinition.Test.Bookingdates;
import com.stepdefinition.Test.CreateBooking;
import com.stepdefinition.Test.CreateBookingResponse;
import com.stepdefinition.practice.DailyPractic.MarvikSystems;
import com.stepdefinition.practice.DailyPractic.WiproInterview;
import com.stepdefinition.wipro.practiceStreams;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import util.CommonDefition;
import java.io.IOException;
public class TestStepdefinition {

    Scenario scenario;
    public CommonDefition Defitionn = new CommonDefition();

    @Before
    public void before(Scenario scenario) {
        this.scenario = scenario;
        //  ReportUtil.setScenario(scenario); // Set the scenario for logging
    }





    @Given("Login to URL")
    public void loginToURL() throws IOException {
        scenario.write("Test123");
        //Test4();
        MarvikSystems ss =  new MarvikSystems();
        ss.RunProgram();



       // pp.Test1();
       // tt.SecondFrequemtCharacter();

        //PojoExample ex = new PojoExample();
        //ex.SerialAndDeserial();
        //test();





        //Hashmapexcample();


//       System.out.println("REverse a String");
//        programs p = new programs();
//        p.Test();
//        System.out.println("Test");
        //  StreamExample  test = new StreamExample();
        //  test.ArrayOnColors();

    //    Defitionn.Test();
    }








    @Given("^Login to URL Booking$")
    public void loginToURLBooking() throws JsonProcessingException {

        CreateBooking booking = new CreateBooking();

        booking.firstname = "Sowmya";
        booking.lastname = "Ankegowda";
        booking.totalprice = 100;
        booking.depositpaid = true;
        booking.additionalneeds = "Sweet";

        Bookingdates bdates = new Bookingdates();
        bdates.checkin = "22-5-2024";
        bdates.checkout = "23-5-2024";

        booking.bookingdates = bdates;

        ObjectMapper mapper = new ObjectMapper();

        String a = mapper.writeValueAsString(booking);

        Response res = RestAssured.given().header("Content-Type","application/json").header("Accept","application/json")
                .body(a)
                .when().log().all().post("https://restful-booker.herokuapp.com/booking").then().log().all().extract().response();




       CreateBookingResponse b =  mapper.readValue(res.body().asString(), CreateBookingResponse.class);






    }

    public void test() throws JsonProcessingException {
        CreateBooking booking = new CreateBooking();

        booking.firstname = "Sowmya";
        booking.lastname = "Ankegowda";
        booking.totalprice = 100;
        booking.depositpaid = true;
        booking.additionalneeds = "Sweet";

        Bookingdates bdates = new Bookingdates();
        bdates.checkin = "22-5-2024";
        bdates.checkout = "23-5-2024";

        booking.bookingdates = bdates;

        ObjectMapper mapper = new ObjectMapper();

        //seralization
        String a = mapper.writeValueAsString(booking);

        Response res = RestAssured.given().header("Content-Type","application/json").header("Accept","application/json")
                .body(a)
                .when().log().all().post("https://restful-booker.herokuapp.com/booking").then().log().all().extract().response();



        //Deseralization

        CreateBookingResponse b =  mapper.readValue(res.body().asString(), CreateBookingResponse.class);


        JsonPath path = new JsonPath(res.body().asString());

        String S1 = path.getString("bookingid");
        String S2 = path.getString("booking.lastname");
        System.out.println(S1);
        System.out.println(S2);
    }
}

