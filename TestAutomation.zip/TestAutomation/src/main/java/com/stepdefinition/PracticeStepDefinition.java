package com.stepdefinition;

import com.stepdefinition.practice.TestPractice;
import cucumber.api.java.en.Given;
import org.testng.annotations.Test;

import java.io.IOException;

public class PracticeStepDefinition {

    public  TestPractice practice = new TestPractice(); ;

    public PracticeStepDefinition(TestPractice practice)
    {
        this.practice = practice;

    }
    @Given("^Login to URL to run program$")
    public void loginToURLToRunProgram() {
        System.out.println("This is the program");
        practice.ReverseString();


    }

    @Given("^learn the program$")
    public void learnTheProgram() {
        System.out.println("This is the program");
        practice.ReverseString();
    }
}
