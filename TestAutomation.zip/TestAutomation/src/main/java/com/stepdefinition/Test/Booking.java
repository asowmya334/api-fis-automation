package com.stepdefinition.Test;

public class Booking {
    public String firstname;
    public String lastname;
    public int totalprice;
    public boolean depositpaid;
    public BookingdatesRes bookingdates;
    public String additionalneeds;
}
