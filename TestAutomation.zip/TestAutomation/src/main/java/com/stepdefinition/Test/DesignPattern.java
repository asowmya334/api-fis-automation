package com.stepdefinition.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DesignPattern {

    public static WebDriver driver = null;
    public static String browser = "chrome";


    public DesignPattern()
    {

    }

    public static WebDriver Initizalize()
    {
        driver = new ChromeDriver();

        return driver;
    }





}
