package com.stepdefinition;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;

import java.io.FileReader;
import java.io.IOException;

import static io.restassured.RestAssured.given;

public class PojoExample {

    public void seralizeAndDeseralizeExamples() throws JsonProcessingException {
        CreateUser2 user23 = new CreateUser2();
        user23.setName("Sowmya");
        user23.setJob("testing");


        ObjectMapper mapper1 = new ObjectMapper();
        mapper1.writeValueAsString(user23);

        Response res = RestAssured.given().when().get("").then().log().all().extract().response();

        mapper1.readValue(res.body().asString(),CreateUser2.class);







        CreateUser2 user2 = new CreateUser2();
        user2.setJob("Testing");
        user2.setName("Spowmya");

        ObjectMapper mapper = new ObjectMapper();

        //seralization
        String json = mapper.writeValueAsString(user2);

       Response res1 = RestAssured.given().body(json).when().post("endpoint").then().log().all().extract().response();


        //deseralization

      ResponsePojo pojo = mapper.readValue(res1.body().asString(),ResponsePojo.class);

    }
    public void SerialAndDeserial() throws JsonProcessingException {

        //Creating pojo object
        CreateUser user = new CreateUser();
        user.setJob("Testing");
        user.setName("Sowmya");
        ObjectMapper mapper = new ObjectMapper();


        //Seralization
        String json = mapper.writeValueAsString(user);

     Response res = given().log().all().body(json)
                .when().post("https://reqres.in/api/users")
                .then().extract().response();

        System.out.println("Test123");

        System.out.println(res.body().prettyPrint());

        //converting response to object

        ResponsePojo resP = mapper.readValue(res.body().asString(),ResponsePojo.class);


        //validating using java object


        String exp = resP.getCreatedAt().toString();
        Assert.assertTrue(exp.contains("2024"));

    }


    public void UsingFile() throws IOException {

        FileReader file = new FileReader("C:\\Users\\HQ11DS\\Sowmya\\TestAutomation\\src\\main\\resources\\Test.json");

        //converting file  to java object - deseralzation
        ObjectMapper mapper = new ObjectMapper();
        CreateUser user = mapper.readValue(file , CreateUser.class);


        //pojo class to json string


        String request = mapper.writeValueAsString(user);



    }


}
