package com.stepdefinition;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class StreamExample {


    public void ArrayOnColors() {

        ArrayList<String> color1 = new ArrayList<>();
        color1.add("orange");
        color1.add("black");
        color1.add("purple");
        color1.add("violet");
        color1.add("red");
        color1.add("green");
        color1.add("green");

        for (String col : color1) {
            System.out.println("this is for each");
            System.out.println(col);
        }

        Iterator it = color1.iterator();
        while (it.hasNext()) {
            System.out.println("this is for iterator");
            System.out.println(it.next());
        }

        System.out.println("this is for streams");
        color1.stream().forEach(System.out::println);
        System.out.println("Stream Filters ");
        List<String> a = color1.stream().filter(item -> item.length() > 5).collect(Collectors.toList());
        System.out.println(color1);
        System.out.println(a);

        a =  color1.stream().map(item -> item + "Test1").collect(Collectors.toList());
        System.out.println(a);

        ArrayList<Integer> item = new ArrayList<>();
        item.add(123);
        item.add(147);
        item.add(456);
        item.add(789);
        item.add(258);
        item.add(369);
        item.add(741);


       Integer n =  item.stream().max(Comparator.comparing(Integer::valueOf)).get();
        System.out.println(n);

        n = item.stream().min(Comparator.comparing(Integer::valueOf)).get();


        //find the first element in array

       String d =  color1.stream().findFirst().toString();
        System.out.println("First element " + d);




    }
}
