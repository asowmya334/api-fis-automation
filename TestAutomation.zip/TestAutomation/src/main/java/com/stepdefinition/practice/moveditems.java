package com.stepdefinition.practice;

import java.util.*;
import java.util.stream.Collectors;

public class moveditems {

    public void testsow()
    {
        List<String> a = new ArrayList<>();
        a.add("Orange");
        a.add("Purpule");
        a.add("Green");
        a.add("Yellow");

        for (String b : a) {
            System.out.println(b);

        }

        Iterator<String> c = a.iterator();
        while (c.hasNext())
        {
            System.out.println(c.next());
        }


        a.stream().forEach(System.out::println);





    }


    public void Test4()
    {
        List<Integer> numbers = Arrays.asList(5, 12, 8, 24, 15, 10);

        Optional<Integer> a =  numbers.stream().max(Integer :: compareTo);

        System.out.println(a);



    }


    public void TestMap()
    {
        HashMap<String ,Integer> test =  new HashMap<>();

        test.put("Black" , 101);
        test.put("red" , 201);
        test.put("white" , 301);

        for (Map.Entry<String ,Integer> test2: test.entrySet()) {
            System.out.println(test2.getKey());
            System.out.println(test2.getValue());

        }


        Iterator<Map.Entry<String , Integer>> test3 = test.entrySet().iterator();

        if(test3.hasNext())
        {
            System.out.println(test3.next().getValue());
            System.out.println(test3.next().getKey());
        }







    }

    public void test3()
    {

        List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "Andrew");

        names.stream().filter(s -> s.startsWith("A")).map( s -> s.toUpperCase()).forEach(System.out::println);



    }









    // Given a String, find the first non-repeated character in it using Stream functions?

    public void NonRepeatedCharacter()
    {
        String input = "This is a string is";

        input.chars().mapToObj(c -> (char) c).filter(ch -> input.indexOf(ch) == input.lastIndexOf(ch)).findFirst().orElse(null);
    }



    //How to find duplicate elements in a given integers list in java using Stream functions?

    public void duplicateElemetn()
    {
        List<Integer> test = Arrays.asList(100,25,74,89,45,74,55,55);
        List<Integer> test2 = new ArrayList<>();
        //Set<Integer> test2 = new HashSet<>();

        test.stream().filter(s -> !test2.add(s)).collect(Collectors.toList()).forEach(System.out::println);




    }

    //Given a list of integers, find out all the numbers starting with 1 using Stream functions?
    public void StartWithInteger()
    {
        List<String> a = Arrays.asList("sowmya", "sreikanth" ,"karnataka", "mangalore");

        a.stream().filter(s -> s.startsWith("man")).forEach(System.out::println);


    }


    ///5- Write a Java program to find out the first two max values from an array?

    //Given a list of integers, find out all the even numbers that exist in the list using Stream functions?
    public void ListOfPrime()
    {

        List<Integer> test = Arrays.asList(10,26,48,74,36,15,47);
        test.stream().filter(s -> s % 2 == 0).forEach(System.out::println);


    }





    public void Max()
    {


        int a[] = {100,42,15,75};
        int firstLargest = Integer.MIN_VALUE;
        int secondLargest =Integer.MIN_VALUE;


        for (int num : a) {
            if(num > firstLargest)
            {
                secondLargest = firstLargest;
                firstLargest = num;

            } else if (num > secondLargest && num != firstLargest) {
                secondLargest = num;

            }


        }


        System.out.println(secondLargest);
        System.out.println(firstLargest);

    }



    public void TwoMax()
    {
        int[] b = {200,41,74,100};

        int firstLargest = Integer.MIN_VALUE;
        System.out.println(firstLargest);
        int secondLargerst = Integer.MIN_VALUE;
        System.out.println(secondLargerst);

        for (int c: b) {
            if(c > firstLargest)
            {
                secondLargerst = firstLargest;
                firstLargest = c;
            }
            else
            if(c >secondLargerst && c!= firstLargest)
            {
                secondLargerst = c;
            }

        }

        System.out.println(secondLargerst);




    }


    //Write a method to check prime no. in Java?

    public void PrimeNumber()
    {
        int a = 15;

        for(int i = 2 ;i < a-1 ; i++)
        {
            if(a/i == 0)
            {
                System.out.println("This is not a prime");
                break;

            }
            else
            {
                System.out.println("Given prime number is not");
            }

        }






    }





    //Write a function to reverse a number in Java?

    public void ReverseFunction()
    {
        String a = "This is a function";
        String rev = "";

        char[] c = a.toCharArray();
        int b = c.length;
        System.out.println(b);
        System.out.println(c[18-1]);

        for(int i = b-1 ; i >= 0 ; i--)
        {
            rev =  rev + c[i] ;

        }
        System.out.println(a);
        System.out.println(rev);






    }


    // Write code to sort the list of strings using Java collection?

    public void SortArrayUsingcollection()
    {
        List<String> ab = new ArrayList<>();
        ab.add("Red");
        ab.add("Browsn");
        ab.add("Black");
        ab.add("Green");
        ab.add("Orange");

        List<String> c =  ab.stream().sorted().collect(Collectors.toList());
        System.out.println(ab);
        System.out.println(c);

    }


    //1- Write code to filter duplicate elements from an array and print as a list?

    public void duplicateElements()
    {
        int[] array = {1, 1,1,2, 3, 4, 2, 5, 6, 3};

        List<Integer> test = new ArrayList<>();

        for(int i = 0 ; i < array.length ; i++ )
        {
            boolean a = test.contains(array[i]);
            System.out.println(a);
            if(a == false)
            {
                test.add(array[i]);
            }

        }

        System.out.println(test);



    }



    public void Hashmapexcample() {

        HashMap<String, String> test = new HashMap<>();
        test.put("monday", "blue");
        test.put("tuesday", "black");
        test.put("wednesday", "green");
        test.put("thursday", "red");
        test.put("friday", "yellow");
        test.put("saturday", "cream");


        System.out.println(test);


        List<String> n = new ArrayList<>();

        //Map.Entry<String , String> ol = test.entrySet();

        for (Map.Entry<String, String> ab : test.entrySet()) {
            n.add(ab.getValue());

        }
        System.out.println(n);


        System.out.println(test.entrySet().stream().filter(entry -> !entry.getKey().equals("tuesday")).collect(Collectors.toList()));


        if (test.containsKey("wednesday")) {

            test.remove("wednesday");

        }
        System.out.println(test);

        Iterator<Map.Entry<String, String>> test1 = test.entrySet().iterator();
        while (test1.hasNext()) {

            Map.Entry<String, String> a = test1.next();
            if (a.getKey().equals("saturday")) {
                test1.remove();

            }

        }

        System.out.println(test);


    }


    public void WorkonList() {
        List<String> st = new ArrayList<>();
        st.add("sunday");
        st.add("monday");
        st.add("tuesday");
        st.add("thursdau");
        st.add("friday");

        System.out.println(st);

        for (String a : st) {
            if (a.contains("rs")) {
                st.remove(a);
            }

        }
        System.out.println(st);

    }

    public void ArrayusingIterator() {

        List<String> st = new ArrayList<>();
        st.add("sunday");
        st.add("monday");
        st.add("tuesday");
        st.add("thursdau");
        st.add("friday");

        System.out.println(st);

        Iterator<String> it = st.iterator();

        while (it.hasNext()) {
            String a = String.valueOf(it);
            if (a.contains("ues")) {
                st.remove(a);
            }

        }

        System.out.println(st);
    }


    public void ArrayListUsingStreams() {
        List<String> st = new ArrayList<>();
        st.add("sunday");
        st.add("monday");
        st.add("tuesday");
        st.add("thursdau");
        st.add("friday");

        System.out.println(st);

        st.stream().filter(a -> !a.startsWith("tue")).collect(Collectors.toList());

        System.out.println(st.stream().filter(a -> !a.startsWith("tue")).collect(Collectors.toList()));

        st.removeIf(item -> item.startsWith("mon"));
        System.out.println(st);


    }
}
