package com.stepdefinition.practice.DailyPractic;

public class dailyPrograms {

    public void callMethod()
    {


    }

    public void SumNumbers()
    {
        int num = 3;
        int start = 1;
        for(int i = 2 ; i< num ; i++)
        {

        }





    }




}
