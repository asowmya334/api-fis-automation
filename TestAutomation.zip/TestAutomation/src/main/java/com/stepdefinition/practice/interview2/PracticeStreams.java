package com.stepdefinition.practice.interview2;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class PracticeStreams {

    public void Example() {
        List<Integer> test = Arrays.asList(10, 25, 14, 63, 11, 45, 95, 74, 14, 10, 11);

        List<String> test1 = test.stream()
                .map(i -> i + "")
                .filter(i -> i.startsWith("1"))
                .collect(Collectors.toList());

        System.out.println(test1);

        Set<Integer> n = new HashSet<>();
        test.stream()
                .filter(s -> !n.add(s))
                        .forEach(System.out:: println);


        System.out.println(n);

        test.stream().findFirst().ifPresent(System.out::println);

       long v =  test.stream().count();
       System.out.println(v);



    }


}
