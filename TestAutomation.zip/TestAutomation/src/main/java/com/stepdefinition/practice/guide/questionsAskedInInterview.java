package com.stepdefinition.practice.guide;

import java.sql.*;
import java.util.HashMap;

public class questionsAskedInInterview {


        public static void main(String[] args) {
            String original = "example";
            String reversed = new StringBuilder(original).reverse().toString();
            System.out.println("Reversed string: " + reversed);
        }

        public void ToReadTheSize()
        {
            HashMap<String, Integer> map = new HashMap<>();
            map.put("key1", 1);
            map.put("key2", 2);
            map.put("key3", 3);

            int count = map.size();
            System.out.println("Total count of items in HashMap: " + count);
        }

        public void connectToDB()
        {
            String url = "jdbc:mysql://localhost:3306/mydatabase";
            String user = "username";
            String password = "password";

            try {
                Connection connection = DriverManager.getConnection(url, user, password);
                System.out.println("Connection successful!");
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT * FROM mytable");
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String name = resultSet.getString("name");
                    System.out.println("ID: " + id + ", Name: " + name);
                }
                resultSet.close();
                statement.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }



}


