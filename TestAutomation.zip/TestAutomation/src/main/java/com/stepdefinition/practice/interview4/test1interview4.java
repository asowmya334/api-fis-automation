package com.stepdefinition.practice.interview4;

import cucumber.api.java.it.Ma;
import lombok.val;

import javax.swing.plaf.synth.SynthUI;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class test1interview4 {

    public void InterviewMethodCall() {
        TestingHashMap();


    }

    public void TestingHashMap()
    {
        HashMap<String, Integer> test = new HashMap<>();

        test.put("Black",1);
        test.put("green",2);
        test.put("blue",3);
        test.put("white",4);
        test.put("orange",21);
        test.put("sweet",14);

        test.size();

       // test.add()

        for (Map.Entry<String , Integer> nn : test.entrySet()) {
            System.out.println(nn.getValue());
            System.out.println(nn.getKey());
        }

        Iterator<Map.Entry<String,Integer>> test1 = test.entrySet().iterator();

        while (test1.hasNext())
        {

            Map.Entry<String,Integer> tt = test1.next();
            tt.getValue();
            tt.getKey();

            System.out.println(test1.next());
        }






    }




    public void Test1ing()
    {
        List<Integer> tt = Arrays.asList(10,25,46,30,47,488);

        for (Integer a : tt) {
            System.out.println(a);

        }

        Iterator<Integer> it = tt.iterator();

        while(it.hasNext())
        {
            System.out.println(it.next());
        }



    }









    public void SortArrayWithOut()
    {

        int[] a = {25,14,60,44};
        int temp;

        for(int i = 0 ; i< a.length ; i++)
        {
            for(int j = 0 ; j <a.length ; j++)
            {
                if(a[i] > a[j])
                {
                    temp = a[i];
                    a[i] = a[j];
                    a[j] =temp;
                }
            }
        }

        for(int i = 0 ; i < a.length ; i++) {
            System.out.println(a[i]);
        }



    }




    public void checkPrime() {
        int num = 11;
        boolean flag = false;

        for (int i = 2; i < num; i++) {

            if (num % i == 0) {
                flag = true;
            }

        }


        System.out.println(flag);
    }


    public void ReverseArray() {

        String a = "Thjis is a String";
        String rev = "";

        for (int i = 0; i < a.length(); i++) {
            rev = a.charAt(i) + rev;


        }


        System.out.println(rev);


    }

    public void OccuraceOfcharacter() {
        String a = "Thjis is a String";
        HashMap<String, Integer> test = new HashMap<>();
        int count = 0;

Arrays.stream(a.split(" ")).collect(Collectors.groupingBy(Function.identity(),HashMap :: new ,Collectors.counting()));

        for (int i = 0; i < a.length(); i++) {
            String b = String.valueOf(a.charAt(i));
            if (test.containsKey(b)) {

                test.put(b, test.get(b) + 1);
            } else
                test.put(b, count);


        }

        System.out.println(test);


    }


    public void IntersectionAndUnion() {
        int[] a = {10, 23, 14, 15, 96, 36, 10, 12};
        int[] intersection = new int[a.length - 1];
        int[] unionSection = new int[a.length - 1];

        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {

                if (a[i] == a[j]) {
                    unionSection[i] = a[i];
                }


            }

        }

        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {

                if (a[i] != a[j]) {
                    intersection[i] = a[i];
                }


            }

        }

        System.out.println(intersection);
        System.out.println(unionSection);

    }


    public void JavaProgramSubArra() {
        int[] a = {10, 23, 14, 15, 96, 36, 10, 12};
        int sum = 29;
        int num;

        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                num = a[i] + a[j];
                if (sum == num) {
                    System.out.println(a[i]);
                    System.out.println(a[j]);
                }


            }


        }


    }


    public void SecondLargest() {
        int[] a = {10, 23, 14, 15, 96, 36, 10, 12};

        int largest = 0;
        int secondLargest = a[0];

        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest) {
                secondLargest = largest;
                largest = a[i];

            } else if (a[i] > secondLargest && a[i] != largest) {
                secondLargest = a[i];
            }


        }

        System.out.println(secondLargest);


    }


    public void firstLarges() {
        int[] a = {10, 23, 14, 15, 96, 36, 10, 12};
        int largest = 0;


        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest) {
                largest = a[i];
            }


        }

        System.out.println(largest);


    }


    public void FindDuplicateElement() {
        int[] a = {10, 23, 14, 15, 96, 36, 10, 12};
        int count = 1;

        HashMap<Integer, Integer> test = new HashMap<>();

        for (int b : a) {
            if (test.containsKey(b)) {
                test.put(b, test.get(b) + 1);
            } else
                test.put(b, count);
        }

        test.entrySet().stream().filter(s -> s.getValue() > 1).forEach(System.out::println);


    }

    public void nonRepeatedCharacter() {
        String a = "this is a sowmya";

        Map<Character, Long> test = a.chars().mapToObj(s -> Character.toLowerCase(Character.valueOf((char) s)))
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println("Even number");
        a.chars().mapToObj(s -> Character.toLowerCase(Character.valueOf((char) s))).forEach(System.out::println);


        a.chars().mapToObj(s -> Character.toLowerCase(Character.valueOf((char) s)));
        a.chars().mapToObj(s -> Character.toLowerCase(Character.valueOf((char) s)));

        System.out.println("Even number");

        System.out.println(a.chars().mapToObj(s -> (char) s).filter(s -> a.indexOf(s) == a.lastIndexOf(s)).findFirst().orElse(null));

        System.out.println(a.chars().mapToObj(s -> Character.toLowerCase(Character.valueOf((char) s))).collect(Collectors.groupingBy(
                        Function.identity(), Collectors.counting()))
                .entrySet()
                .stream()
                .filter(s -> s.getValue() > 1)
                .map(s -> s.getKey())
                .findFirst()
                .orElse(null));


    }


    public void StreamWithNumber() {
        List<Integer> tt = Arrays.asList(10, 15, 74, 95, 36, 10);

        System.out.println("Even number");
        tt.stream().filter(e -> e % 2 == 0).forEach(System.out::println);

        System.out.println("starst wiht 1");
        tt.stream().map(String::valueOf).filter(s -> s.startsWith("1")).forEach(System.out::println);

        System.out.println("find duplkicate element");
        Set<Integer> set = new HashSet();
        List<Integer> ww = new ArrayList<>();
        ww = tt.stream().filter(n -> !set.add(n)).collect(Collectors.toList());
        System.out.println(ww);

        System.out.println("find first element");
        System.out.println(tt.stream().findFirst().orElse(null));

        System.out.println("total Nuimber i n the list");
        System.out.println(tt.stream().count());

        System.out.println("find the max");
        System.out.println(tt.stream().max(Integer::compare));
    }


}
