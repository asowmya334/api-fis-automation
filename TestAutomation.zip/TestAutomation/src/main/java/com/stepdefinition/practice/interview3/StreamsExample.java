package com.stepdefinition.practice.interview3;

import gherkin.lexer.Sr_cyrl;
import groovy.util.MapEntry;

import java.util.*;
import java.util.stream.Collectors;

public class StreamsExample {

    public void callMethod()
    {

        SubArry();


    }

    public void SecondFrequesntcharacter()
    {
        String a = "DevLabsAlliance";
        HashMap<String , Integer> test = new HashMap<>();
        int count = 1 ;

        for(int i = 0 ;  i< a.length() ; i++ )
        {
            if(test.containsKey(a.charAt(i)))
            {
                count = count + test.get(a.charAt(i));
                test.put(String.valueOf(a.charAt(i)),count);
            }
            else
            {
                test.put(String.valueOf(a.charAt(i)),count);
            }

        }

        int largetst = 0;
        int secondlargest = 0;

        Iterator<Map.Entry<String,Integer>> test2 = test.entrySet().iterator();
        for (Map.Entry<String ,Integer> test3: test.entrySet()) {
          int c = test3.getValue();
          if(c > largetst)
          {
              secondlargest = largetst;
              largetst = c;

          } else if (c > secondlargest && c != largetst) {

              secondlargest = c;
          }


        }


        System.out.println(largetst);
        System.out.println(secondlargest);




    }

    public void ReverseString()
    {
        String a = "this is a program";
        String rev = "";
        char[] c = a.toCharArray();

        for(int i = 0 ; i  < a.length() ; i++)
        {

            rev = a.charAt(i) + rev;

        }


        System.out.println(rev);


    }



    public void HashMapExample()
    {
        HashMap<String , Integer> test = new HashMap<>();
        test.put("orange",1);
        test.put("yellow",1);
        test.put("purple",1);
        test.put("green",1);
        test.put("grey",1);


        for (Map.Entry<String , Integer> test1 : test.entrySet()) {

            System.out.println(test1.getValue());
            System.out.println(test1.getKey());
        }

        Iterator<Map.Entry<String , Integer>> it = test.entrySet().iterator();

        while(it.hasNext())
        {
            System.out.println(it.next());
        }





    }



















    public void SubArry()
    {
        int[] a= {1,2,4,15,10,12,16};
        int[] b = new int[a.length-1];
        int sum = 22;
        int num = 0;
        int start = 0;

        for(int end = 0 ; end < a.length ; end++)
        {
            num = num + a[end];

            while(num > sum && start <= end)
            {
                num = num - a[start];
                start++;


            }

            if(sum == num){
                System.out.println("Sum found between indexes " + start + " and " + end);
                for(int i = start ; i< end ; i++)
                {
                    System.out.println(a[i]);
                }


            }


        }




    }

    public void SumEqualToNum()
    {
        int[] a = {1,12,3,14,25};
        int num  = 15;
        int sum = 0 ;


        for(int i = 0 ; i < a.length ; i++)
        {
            for(int j = i+1 ; j < a.length ; j++)
            {
                sum = a[i] + a[j];
                if(sum == num)
                {
                    System.out.println(a[i]);
                    System.out.println(a[j]);
                }


            }


        }






    }





    public void Secondhightest()
    {
        int[] a = {10,12,14,84,62,14,75,12,96};
        int largest = a[0];
        int secondLargest = a[0];

        for(int i = 0 ; i < a.length ; i++)
        {
            if(a[i] > largest)
            {

                secondLargest = largest;
                largest = a[i];
            }
            else
                if(a[i] > secondLargest && a[i] != largest)
            {
                secondLargest = a[i];
            }




        }

        System.out.println(secondLargest);



    }


    public void FirstLargest()
    {
        int[] a = {10,12,14,84,62,14,75,12,96};
        int largest = a[0];
        int secondLargest = a[0];

        for(int i = 0 ; i < a.length ; i++)
        {
            if(a[i] > largest)
            {
                largest = a[i];
            }


        }

        System.out.println(largest);







    }




    public void FindDuplicateElement()
    {
       int[] a = {10,12,14,12,15,14};
       int[] b =  new int[a.length -1 ];

       for(int i = 0 ;i < a.length ; i++)
       {
           for(int j = i +1  ; j <a.length ; j++)
           {

               if(a[i] == a [j])
               {
                   b[i] = a[i];
                   System.out.println(b[i]);
                   break;
               }

           }



       }









    }









    public void SortArray()
    {
        List<Integer> test = Arrays.asList(10,44,15,21,74,11,99);

        test.stream().sorted(Collections.reverseOrder()).forEach(System.out::println);


    }

    public void firstRepeatedCharacter()
    {

        String a = "this is java program";
        Set<Character> ss = new HashSet<>();

        a.chars().mapToObj(s -> (char) s).filter(s -> !ss.add(s)).forEach(System.out::println);

        a.chars().mapToObj(s -> (char) s).filter(s -> !ss.add(s)).forEach(System.out::println);




    }


    public void FirstNonRepeatedCharacter()
    {

        String  a = "This is java program";
        System.out.println(a.indexOf("i"));
        System.out.println(a.lastIndexOf("i"));

        a.chars().mapToObj(s -> (char) s)
                .filter(b -> a.indexOf(b) == a.lastIndexOf(b))
                .peek(s -> System.out.println(s))
                .forEach(System.out :: println);


       // a.chars().mapToObj(c ->(char) c).filter(s -> a.indexOf(s) == a.lastIndexOf(s)).


    }

    public void MaxElement()
    {
        List<Integer> test = Arrays.asList(10,25,11,45,84,95,14,25);

        int  a = test.stream().max(Integer :: compare).get();
        System.out.println(a);





    }

    public void toalElement()
    {
        List<Integer> test = Arrays.asList(10,25,46,39,75,14,95,74);

        long count = test.stream().count();

        System.out.println(count);





    }


    public void FindFirstElement()
    {
        List<Integer> test = Arrays.asList(10,15,47,25,16);

        test.stream().findFirst().ifPresent(System.out::println);





    }

public void DuplicatioElemetn()
{
    List<Integer> test = Arrays.asList(10,15,24,10);
    Set<Integer> test2 = new HashSet<>();

    test.stream().filter(s -> !test2.add(s)).forEach(System.out::println);



}




    public void StrastWithOne()
    {
        List<Integer> test = Arrays.asList(25,45,17);
        test.stream().map(s -> s.toString())
                .filter(s -> s.startsWith("1"))
                .forEach(System.out::println);



    }

    public void CheckEvenAndODD()
    {
        List<Integer>  test = Arrays.asList(10,15,42,18,13,14);

        test.stream().filter(e -> e % 2 == 0 ).forEach(System.out::println);





    }








}
