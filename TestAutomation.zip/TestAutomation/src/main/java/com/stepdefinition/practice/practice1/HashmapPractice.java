package com.stepdefinition.practice.practice1;

import groovy.util.MapEntry;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashmapPractice {

    public void Test1()
    {
        HashMap<String , Integer> test = new HashMap<>();
        test.put("Orange", 2);
        test.put("Green" , 3);
        test.put("Yellow", 4);
        test.put("Purpule",5);
        test.put("Red",6);



        Iterator<Map.Entry<String,Integer>> nn =test.entrySet().iterator();

        while(nn.hasNext())
        {

        }





        //foreach

        for (Map.Entry<String , Integer> map : test.entrySet()) {
            System.out.println("Scenario 1 display only key and valuu1");
            System.out.println(map.getKey());
            System.out.println(map.getValue());

            }

        for (String key: test.keySet()) {
            System.out.println("Scenario 2 display only key ");
            System.out.println(key);
        }

        Iterator<Map.Entry<String,Integer>> it = test.entrySet().iterator();

        while (it.hasNext())
        {
            System.out.println("Scenario 3 display only key ");
            System.out.println(it.next());

        }




    }









}
