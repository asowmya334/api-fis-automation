package com.stepdefinition.practice.DailyPractic;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.ReadContext;
import org.json.JSONArray;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MarvikSystems {

    private  static JSONArray jsonArray;
    public void RunProgram() {

        ArrayJsonValidation();


    }

    public void ArrayJsonValidation() {

        String json = "[\n" +
                "   {\"id\": \"1\", \"name\": \"Google Pixel 6 Pro\", \"data\": {\"color\": \"Cloudy White\", \"capacity\": \"128 GB\"}},\n" +
                "   {\"id\": \"2\", \"name\": \"Apple iPhone 12 Mini, 256GB, Blue\", \"data\": null},\n" +
                "   {\"id\": \"3\", \"name\": \"Apple iPhone 12 Pro Max\", \"data\": {\"color\": \"Cloudy White\", \"capacity GB\": 512}},\n" +
                "   {\"id\": \"4\", \"name\": \"Apple iPhone 11, 64GB\", \"data\": {\"price\": 389.99, \"color\": \"Purple\"}},\n" +
                "   {\"id\": \"5\", \"name\": \"Samsung Galaxy Z Fold2\", \"data\": {\"price\": 689.99, \"color\": \"Brown\"}},\n" +
                "   {\"id\": \"6\", \"name\": \"Apple AirPods\", \"data\": {\"generation\": \"3rd\", \"price\": 120}},\n" +
                "   {\"id\": \"7\", \"name\": \"Apple MacBook Pro 16\", \"data\": {\"year\": 2019, \"price\": 1849.99, \"CPU model\": \"Intel Core i9\", \"Hard disk size\": \"1 TB\"}},\n" +
                "   {\"id\": \"8\", \"name\": \"Apple Watch Series 8\", \"data\": {\"Strap Colour\": \"Elderberry\", \"Case Size\": \"41mm\"}},\n" +
                "   {\"id\": \"9\", \"name\": \"Beats Studio3 Wireless\", \"data\": {\"Color\": \"Red\", \"Description\": \"High-performance wireless noise cancelling headphones\"}},\n" +
                "   {\"id\": \"10\", \"name\": \"Apple iPad Mini 5th Gen\", \"data\": {\"Capacity\": \"64 GB\", \"Screen size\": 7.9}},\n" +
                "   {\"id\": \"11\", \"name\": \"Apple iPad Mini 5th Gen\", \"data\": {\"Capacity\": \"254 GB\", \"Screen size\": 7.9}},\n" +
                "   {\"id\": \"12\", \"name\": \"Apple iPad Air\", \"data\": {\"Generation\": \"4th\", \"Price\": \"419.99\", \"Capacity\": \"64 GB\"}},\n" +
                "   {\"id\": \"13\", \"name\": \"Apple iPad Air\", \"data\": {\"Generation\": \"4th\", \"Price\": \"519.99\", \"Capacity\": \"256 GB\"}}\n" +
                "]";

        ReadContext ctx = JsonPath.parse(json);
        Object result = ctx.read("$[?(@.name == 'Samsung Galaxy Z Fold2')].data.price");
        System.out.println(result);

        jsonArray = new JSONArray(json);
        for(int i=0;i<jsonArray.length();i++) {
            String c = jsonArray.getJSONObject(i).get("name").toString();
            if(c.equalsIgnoreCase("Apple AirPods"))
            {
                System.out.println(jsonArray.getJSONObject(i).get("Price").toString());
            }
            System.out.println(c);
           List<String> b = Collections.singletonList(jsonArray.getJSONObject(i).get("name").toString());
            //    jsonArray.getJSONObject(i).get("involvedPartyInvolvedPartyRelationshipIdentifier").toString());
        }
    }



    public void ArrayAddition()
    {
        int[] a =  {1, 2, 3, 4, 5, 6, 7, 8, 9, 2};
        List<Integer[]> tt = new ArrayList<>();
        int start = 0 ;
        int end ;


        for(int i = 0 ; i < a.length ; i++)
        {
            start = i;
            end = start + 4;
            if(end < a.length) {
                int[] c = Test(a, start, end);
                Integer[] d = Arrays.stream(c).mapToObj(n -> Integer.valueOf(n)).toArray(Integer[] :: new);
                tt.add(d);
            }


            i = end;

        }

System.out.println(tt);


    }

    public int[] Test(int[] a , int start , int end)
    {
        int[] b = new int[4];
        for(int i = start ; i < end ; i++ )
        {
            for(int j = 0 ; i <= b.length ; j++)
            {
                b[j] = a[i];
            }


        }
        return b;
    }


    public void SortArray()
    {
        int[] a = {10,25,49,36,35,74};
        int temp = 0 ;

        for(int i = 0 ; i < a.length ; i ++)
        {
            for(int j = i+1 ; j<a.length ; j++)
            {
                if(a[i] > a[j])
                {
                  temp = a[i];
                  a[i] = a[j];
                  a[j]  = temp;

                }


            }


        }
        System.out.println(Arrays.toString(a));




    }

    public void TestOnMAP()
    {
        HashMap<String ,Integer> tt = new HashMap<>();

        tt.put("Organge",1);
        tt.put("Yellow",2);
        tt.put("Blue",3);
        tt.put("Black",6);

        tt.entrySet().stream().sorted();

        for (Map.Entry<String ,Integer> ss: tt.entrySet()) {
           System.out.println(ss.getKey());
           System.out.println(ss.getValue());

        }

        Iterator<Map.Entry<String ,Integer>> nn = tt.entrySet().iterator();

        while(nn.hasNext())
        {
            System.out.println(nn.next());
        }




    }




    public void RemovedProvidedValue() {
        int[] num = {3, 2, 2, 3};
        int val = 3;
        int test = Arrays.stream(num).boxed().filter(n -> n != val).findFirst().orElseThrow(() -> new IllegalArgumentException("No element found after removal"));


        System.out.println(test);

        for (int i = 0; i < num.length; i++) {
            if (num[i] == val) {

            }

        }


    }


    public void CheckDuplicateAndREverse() {
        String a = "1236985sowmya15sowmya1234";
        String rev = "";


        for (int i = 0; i < a.length(); i++) {
            String b = String.valueOf(a.charAt(i));
            if (!rev.contains(b)) {
                rev = b + rev;
            }
        }
        System.out.println(rev);

        // List<Character> test = a.chars().mapToObj(n -> (char) n).distinct().collect(Collectors.toList());

        // test.stream().sorted(Collections.reverseOrder()).forEach(System.out::println);

        List<Character> test = a.chars()
                .mapToObj(n -> (char) n)
                .distinct()
                .sorted(Collections.reverseOrder())
                .collect(Collectors.toList());

        test.forEach(System.out::println);

        String reversed = new StringBuilder(a).reverse().toString();
        System.out.println(reversed);

    }

    //nth element in the array
    public void NthElement() {
        int[] a = {10, 25, 96, 36, 48, 62, 36};
        int n = 3;

        Integer[] d = Arrays.stream(a).mapToObj(e -> Integer.valueOf(e)).toArray(Integer[]::new);

        if (n > a.length) {
            System.out.println("Not a valid number");
        } else {
            Arrays.sort(d, Collections.reverseOrder());
            System.out.println(Arrays.toString(a));
            System.out.println(a[n - 1]);
        }
    }

    public void DuplicateString() {
        String a = "Sowmya Ankegowda";

        HashMap<Character, Long> c = a.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));
        System.out.println(c);

        HashMap<String, Integer> tt = new HashMap<>();
        int count = 1;

        for (int i = 0; i < a.length(); i++) {
            String d = String.valueOf(a.charAt(i));
            if (tt.containsKey(d)) {
                tt.put(d, tt.get(d) + 1);
            } else {
                tt.put(d, count);
            }


        }
        System.out.println(tt);

    }

    public void EvenOrODD() {
        int num = 10;

        if (num % 2 == 0
        ) {
            System.out.println("Number is even");
        } else {
            System.out.println("Number is odd");
        }


    }

    public void Factorial() {
        int num = 5;
        int res = 1;

        for (int i = 1; i <= num; i++) {
            res = res * i;
        }
        System.out.println(res);

    }

    public void Fibbonaci() {
        int num = 5;
        int num1 = 0;
        int num2 = 1;
        int num3;

        System.out.println(num1);
        System.out.println(num2);

        for (int i = 2; i <= num; i++) {
            num3 = num1 + num2;
            num1 = num2;
            num2 = num3;
            System.out.println(num3);
        }
    }

    public void CheckPrimeNumber() {
        int num = 8;
        boolean flag = true;

        for (int i = 2; i < num; i++) {
            if (num % i == 0) {
                flag = false;
            }


        }

        if (flag == true) {
            System.out.println("is a a rpime");
        } else {
            System.out.println("It is not aprime");
        }


    }


    public void FirstLargest() {
        int[] a = {10, 25, 96, 36, 48, 62, 36};
        int firstLargest = a[0];

        for (int i = 0; i < a.length; i++) {
            if (a[i] > firstLargest) {
                firstLargest = a[i];
            }

        }

        System.out.println(firstLargest);

    }


    //Second Largest element
    public void SecondLargest() {
        int[] a = {10, 25, 96, 36, 48, 62, 36};
        int firstLargest = a[0];
        int secondLargest = a[0];

        for (int i = 0; i < a.length; i++) {
            if (a[i] > firstLargest) {
                secondLargest = firstLargest;
                firstLargest = a[i];
            } else if (a[i] > secondLargest && a[i] != firstLargest) {
                secondLargest = a[i];

            }  }

        System.out.println(secondLargest);


    }


}
