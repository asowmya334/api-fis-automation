package com.stepdefinition.practice.DailyPractic;






import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.ReadContext;
import io.restassured.response.Response;

import org.json.JSONArray;
import org.json.JSONObject;


import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static io.restassured.RestAssured.given;

public class WiproInterview {

    private  static JSONArray jsonArray;
    public void test() {
        ArrayJsonValidation();

    }


    public void ArrayJsonValidation() {

        String json = "[\n" +
                "   {\"id\": \"1\", \"name\": \"Google Pixel 6 Pro\", \"data\": {\"color\": \"Cloudy White\", \"capacity\": \"128 GB\"}},\n" +
                "   {\"id\": \"2\", \"name\": \"Apple iPhone 12 Mini, 256GB, Blue\", \"data\": null},\n" +
                "   {\"id\": \"3\", \"name\": \"Apple iPhone 12 Pro Max\", \"data\": {\"color\": \"Cloudy White\", \"capacity GB\": 512}},\n" +
                "   {\"id\": \"4\", \"name\": \"Apple iPhone 11, 64GB\", \"data\": {\"price\": 389.99, \"color\": \"Purple\"}},\n" +
                "   {\"id\": \"5\", \"name\": \"Samsung Galaxy Z Fold2\", \"data\": {\"price\": 689.99, \"color\": \"Brown\"}},\n" +
                "   {\"id\": \"6\", \"name\": \"Apple AirPods\", \"data\": {\"generation\": \"3rd\", \"price\": 120}},\n" +
                "   {\"id\": \"7\", \"name\": \"Apple MacBook Pro 16\", \"data\": {\"year\": 2019, \"price\": 1849.99, \"CPU model\": \"Intel Core i9\", \"Hard disk size\": \"1 TB\"}},\n" +
                "   {\"id\": \"8\", \"name\": \"Apple Watch Series 8\", \"data\": {\"Strap Colour\": \"Elderberry\", \"Case Size\": \"41mm\"}},\n" +
                "   {\"id\": \"9\", \"name\": \"Beats Studio3 Wireless\", \"data\": {\"Color\": \"Red\", \"Description\": \"High-performance wireless noise cancelling headphones\"}},\n" +
                "   {\"id\": \"10\", \"name\": \"Apple iPad Mini 5th Gen\", \"data\": {\"Capacity\": \"64 GB\", \"Screen size\": 7.9}},\n" +
                "   {\"id\": \"11\", \"name\": \"Apple iPad Mini 5th Gen\", \"data\": {\"Capacity\": \"254 GB\", \"Screen size\": 7.9}},\n" +
                "   {\"id\": \"12\", \"name\": \"Apple iPad Air\", \"data\": {\"Generation\": \"4th\", \"Price\": \"419.99\", \"Capacity\": \"64 GB\"}},\n" +
                "   {\"id\": \"13\", \"name\": \"Apple iPad Air\", \"data\": {\"Generation\": \"4th\", \"Price\": \"519.99\", \"Capacity\": \"256 GB\"}}\n" +
                "]";

        ReadContext ctx = JsonPath.parse(json);
        Object result = ctx.read("$[?(@.name == 'Samsung Galaxy Z Fold2')].data.price");
        System.out.println(result);

        jsonArray = new JSONArray("json");
        for(int i=0;i<jsonArray.length();i++) {
        //    jsonArray.getJSONObject(i).get("involvedPartyInvolvedPartyRelationshipIdentifier").toString());
        }
    }



    public void RemoveDuplicates1()
    {
        int[] nums = {0,0,1,1,1,2,2,3,3,4} ;
        int[] expectedNums = new int[nums.length-1];
        int k = removeDuplicates(nums);
        assert k == expectedNums.length;
        for (int i = 0; i < k; i++) {
            assert nums[i] == expectedNums[i];
        }

        System.out.println(expectedNums);
    }

    public int removeDuplicates(int[] nums) {
        if (nums.length == 0) return 0;

        int k = 1; // Start with the first element as unique
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] != nums[i - 1]) {
                nums[k] = nums[i];
                k++;
            }
        }

        return k;
    }







    //Given an integer array nums sorted in non-decreasing order, remove some duplicates in-place such that each unique element appears at most twice. The relative order of the elements should be kept the same.
    public void RemoveDuplicatesMoreThan() {
        int[] nums = {1,1,1,2,2,3};
      HashMap<Integer , Integer> tt = new HashMap<>();
      List<Integer> res = new ArrayList<>();
        for(int i = 0 ; i < nums.length ; i++)
        {
            int c =Integer.valueOf(nums[i]);
            if(tt.containsKey(c))
            {

                tt.put(c , tt.get(c) + 1 );
            }
            else {
                tt.put(c ,1 );
            }
        }

        System.out.println(tt);

        for (Map.Entry<Integer ,Integer> test: tt.entrySet()) {

            if(test.getValue() >= 2)
            {
                int c = test.getKey();
                for(int i = 1 ; i <= 2 ; i++)
                {
                    res.add(c);

                }
            }
            else
                res.add(test.getKey());

        }

        System.out.println(res);

        System.out.println(res.size());





    }

    public int  countChar(int[] test , int number)
    {
        int count = 0;
        for(int i = 0 ; i < test.length ; i++)
        {
            if(test[i] == number)
            {
                count = count + 1;
            }
        }
        return count;

    }


    public void CheckEndPint() {
        String json = "{\n" +
                "    \"name\": \"Apple MacBook Pro 16\",\n" +
                "    \"data\": {\n" +
                "        \"year\": 2019,\n" +
                "        \"price\": 1849.99,\n" +
                "        \"CPU model\": \"Intel Core i9\",\n" +
                "        \"Hard disk size\": \"1 TB\"\n" +
                "    }\n" +
                "}";

        Response res = given()
                .header("Content-Type", "application/json")
                .header("Host", "api.restful-api.dev")
                .when().body(json).log().all()
                .post("http://api.restful-api.dev/objects")
                .then()
                .log().all()
                .extract().response();

    }


    public void SprlitAndArray() {
        int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 2};
        List<int[]> b = CplitArray(a, 5);
        Iterator<int[]> it = b.iterator();

        while (it.hasNext()) {
            //  System.out.println(it[0]);
        }
    }

    public List<int[]> CplitArray(int[] a, int size) {
        int count = 4;
        List<int[]> resultArray = new ArrayList<>();
        for (int i = 0; i < a.length; i++) {
            count = i + 4;
            resultArray.add(Arrays.copyOfRange(a, i, count));
            i = count;

        }

        return resultArray;

    }


    public void ReplaceAndReverse() {
        //replace a with w and o  with z
        String a = "sowmya Ankegowda";
        String res = "";
        int start = 0;
        int end = 0;
        String b[] = a.split(" ");
        for (String n : b) {
            for (int i = 0; i < n.length(); i++) {

                start = i;
                end = i + 1;
                if (end < n.length()) {
                    res = res + reverseWord(n, start, end);
                    i = end;

                } else {
                    res = res + n.charAt(i);
                    i = end;
                }


            }

        }
        System.out.println(res);

    }

    public String reverseWord(String a, int start, int end) {
        String res = "";
        for (int i = start; i <= end; i++) {
            res = a.charAt(i) + res;
        }
        System.out.println(res);
        return res;

    }


    public void ArrayAddtion() {

        int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 2};
        int count = 0;
        int res = 0;
        int start = 0;
        int end = 0;


        for (int i = 0; i < a.length; i++) {
            if (count == 0) {
                start = i;
                end = i + 1;
                res = GetSum(a, start, end) + res;
                count = count + 1;
            } else {
                start = i;
                end = i + 2;
                res = GetSum(a, start, end) + res;
                count = 0;

            }
            i = end;

        }
        System.out.println(res);

    }

    public int GetSum(int[] a, int start, int end) {
        String res = "";
        for (int i = start; i <= end; i++) {
            res = res + String.valueOf(a[i]);

        }

        System.out.println(res);
        return Integer.valueOf(res);

    }




    public void RemovedProvidedValue() {
        int[] num = {3, 2, 2, 3};
        int val = 3;
        int test = Arrays.stream(num).boxed().filter(n -> n != val).findFirst().orElseThrow(() -> new IllegalArgumentException("No element found after removal"));


        System.out.println(test);

        for (int i = 0; i < num.length; i++) {
            if (num[i] == val) {

            }

        }


    }


    public void CheckDuplicateAndREverse() {
        String a = "1236985sowmya15sowmya1234";
        String rev = "";

        for (int i = 0; i < a.length(); i++) {
            if (!rev.contains(String.valueOf(a.charAt(i)))) {
                rev = String.valueOf(a.charAt(i)) + rev;
            }

        }

        System.out.println(rev);
        a.chars().mapToObj(s -> (char) s).distinct().collect(Collectors.toList());

        List<Character> b = a.chars().mapToObj(s -> (char) s).distinct().collect(Collectors.toList());
        System.out.println(b);

        Iterator<Character> tt = b.iterator();

        while (tt.hasNext()) {
            rev = tt.next() + rev;


        }

        System.out.println(rev);


    }


    public void DuplicateString() {
        String a = "Thi sis a somwya";

        HashMap<Character, Long> bb = a.chars().mapToObj(s -> (char) s).collect(Collectors.groupingBy(Function.identity(), HashMap::new, Collectors.counting()));

        System.out.println(bb);


    }


    public void EvenOrODd() {
        int num = 4;
        for (int i = 0; i < num - 1; i++) {
            if (num % 2 == 0) {
                System.out.println("This is even number");
            } else {
                System.out.println("This is odd number");
            }


        }


    }

    public void Factorial() {
        int num = 5;
        int result = 1;
        for (int i = 1; i <= num; i++) {

            result = result * i;


        }
        System.out.println(result);


    }


    public void Fibbonaci() {

        int num = 4;
        int num1 = 0;
        int num2 = 1;
        int num3 = 0;

        for (int i = 1; i <= num; i++) {
            num3 = num1 + num2;
            num1 = num2;
            num2 = num3;

            System.out.println(num3);


        }


    }


    public void CheckPrimeNumber() {
        int num = 5;
        boolean flag = false;

        for (int i = 2; i < num - 1; i++) {
            if (num % i == 0) {
                flag = true;
            }


        }

        if (flag == true) {
            System.out.println("Not a prime");
        } else {
            System.out.println("Prime");
        }

    }


    public void FindLargest() {
        int[] a = {10, 25, 69, 34};
        int findLargest = a[0];

        for (int i = 0; i < a.length; i++) {
            if (a[i] > findLargest) {
                findLargest = a[i];
            }


        }

        System.out.println(findLargest);

    }


    public void SecondLargest() {

        int[] a = {10, 25, 963, 14, 58, 333, 444};
        int largest = a[0];
        int secondLargest = a[0];

        for (int i = 0; i < a.length; i++) {

            if (a[i] > largest) {
                secondLargest = largest;
                largest = a[i];

            }
            if (a[i] != largest && a[i] > secondLargest) {
                secondLargest = a[i];
            }


        }
        System.out.println(secondLargest);


    }


}
