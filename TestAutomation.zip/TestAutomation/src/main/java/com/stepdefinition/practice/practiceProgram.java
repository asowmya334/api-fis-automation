package com.stepdefinition.practice;

public class practiceProgram {

    //No of spaces and no of workds in the given string

    public void NoOfWords()
    {
        String s = "This  is a java program to check the number of words between program and between";
        String b = s.substring(s.indexOf("java") , s.indexOf("between"));
















    }




}
