package com.stepdefinition.practice;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class practiceinterview {


    public void praciceinterviewMethodCall() {

        ListOfEvenNumber1();
    }

    public void firstRepeatedNonCharacter()
    {
       String a = "Java articles are Awesome";



        System.out.println("first repeated characters");
        a.chars().mapToObj(c -> (char) c)
                .filter(s -> a.indexOf(s) != a.lastIndexOf(s)).forEach(System.out::println);

        System.out.println("first non repeated characters");
     char b = a.chars().mapToObj(c -> (char) c)
              .filter(ch -> a.indexOf(ch) == a.lastIndexOf(ch)).findFirst().orElse(null);

     System.out.println(b);



    }


    public void ListOfEvenNumber1()
    {
        List<Integer> tt = Arrays.asList(11,14,51,12,22,11);
        System.out.println("Sorted descing");
        tt.stream().sorted(Collections.reverseOrder()).forEach(System.out::println);
        System.out.println("Sorted");
        tt.stream().sorted().forEach(System.out::println);
        System.out.println("maximum value element present");
        System.out.println(tt.stream().max(Integer::compare));
        System.out.println("Totla number of list");
        System.out.println(tt.stream().count());
        System.out.println("find first");
        System.out.println(tt.stream().findFirst());
        System.out.println("unique number with 1");
        Set<Integer> aa =new HashSet<>();
        tt.stream().filter(s -> !aa.add(s)).forEach(System.out :: println);
        System.out.println("Numbers starts with 1");
        tt.stream().map(s -> s + "").filter(e-> e.startsWith("1")).forEach(System.out::println);
        System.out.println("even Numbers");
        tt.stream().filter(e -> e % 2 == 0).forEach(System.out ::println);
    }




    public void ConvertToUpperCase()
    {
        List<String> aa = Arrays.asList("AA","BB","CC","DD");

        aa.stream().map(String :: toLowerCase).forEach(System.out::println);
        aa.stream().map(String::toLowerCase).forEach(System.out::println);
        aa.stream().map(String:: toLowerCase).forEach(System.out::println);
        aa.stream().map(String :: toLowerCase).forEach(System.out::println);





    }




    public void SortArray()
    {
        int[] a = {10,54,13,25,81,12};
        Arrays.sort(a);
        System.out.println(Arrays.toString(a));

        Arrays.stream(a).forEach(System.out :: println);
    }




    public void Checkcube()
    {
        List<Integer> aa = Arrays.asList(1,10,25,14,69);
        aa.stream()
                .map(e -> e*e*e)
                .filter(e -> e > 50)
                .forEach(System.out::println);

    }



    public void duplicateNumber()
    {
        List<Integer> test = Arrays.asList(1,2,3,4,5,6,1,2,10);
        Map<Integer, Long> tes1 = test.stream()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet().stream()
                .filter(e -> e.getValue() > 1)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        for (Map.Entry<Integer , Long> tt: tes1.entrySet()) {
            if(tt.getValue() > 1)
            {
                System.out.println("false");
            }

        }
        System.out.println("true");
        System.out.println(tes1);
  }




    public void countOfeachcharInString() {

        String a = "sowmyta";
        List<String> aa = Arrays.asList("this is the String this is");

        Map<String, Long> mapObject = Arrays.stream(a.split(""))
                .map(String::toLowerCase)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet()
                .stream()
                .filter(entry -> entry.getValue() > 1)
                .collect(Collectors.toMap(Map.Entry::getKey , Map.Entry::getValue));

        System.out.println(mapObject);
    }

    public void MaxElement()
    {
        List<Integer> tt = Arrays.asList(12,19,20,88,00,9);
        Optional<Integer> maxValue = tt.stream().max(Integer::compareTo);
        System.out.println(maxValue);
        Optional<Integer> maxValue1 = tt.stream().max(Integer::compare);
        System.out.println(maxValue1);

    }

    public void DuplicateElementWithCount()
    {
        List<String> aa = Arrays.asList("AA","abc","AA","cde","AA");

        Map<String , Long> nn = aa.stream().collect(Collectors.groupingBy(
                Function.identity(),Collectors.counting()))
                .entrySet()
                .stream()
                .filter(entry -> entry.getValue() > 1)
                .collect(Collectors.toMap(Map.Entry::getKey , Map.Entry::getValue));;

        System.out.println(nn);




    }

}
