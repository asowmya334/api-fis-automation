package com.stepdefinition.practice.interview2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class ArraysProgram {

    public void DuplicateElements() {
        int[] input = {10, 21, 10, 14, 45, 21};
        List<Integer> test = new ArrayList<>();
        int[] duplicate = new int[10];

        for (int i = 0; i < input.length - 1; i++) {
            for (int j = i + 1; j <= input.length - 1; j++) {
                if (input[i] == input[j]) {

                    test.add(input[i]);
                    duplicate[i] = input[i];

                }


            }


        }
        System.out.println(test);
        System.out.println(Arrays.toString(duplicate));


    }


    public void FindSecondHighest() {
        int[] input = {10, 24, 84, 65, 12, 14};
        int largest = 0;
        int secondLargest = input[0];

        for (int i = 0; i <= input.length - 1; i++) {
            if (input[i] > largest) {
                secondLargest = largest;
                largest = input[i];
            } else if (input[i] > secondLargest && input[i] != largest) {
                secondLargest = input[i];

            }
        }
        System.out.println(secondLargest);
        System.out.println(largest);
    }

    public void CheckTwoArraysEqual() {

        int[] a = {10, 20, 30};
        int[] b = {10, 20, 30};

        Arrays.equals(a, b);
    }

    public void CheckNum() {
        int[] input = {12, 41, 15, 20, 45, 10};
        int num = 30;
        int sum = 0;
        List<Integer> test = new ArrayList<>();

        for (int i = 0; i < input.length - 1; i++) {
            for (int j = i + 1; j < input.length - 1; j++) {
                sum = input[i] + input[j];
                if (sum <= num) {
                    test.add(input[i]);
                    test.add(input[j]);
                }
            }
        }
        System.out.println(test);
    }

    public void IntersectionOfArray() {
        int[] arr1 = {10, 30, 40, 20, 60, 70};
        int[] arr2 = {10, 20, 44, 55, 66};
        List<Integer> a = new ArrayList<>();

        for (int i = 0; i <= arr1.length - 1; i++) {
            for (int j = 0; j <= arr2.length - 1; j++) {
                if (arr1[i] == arr2[j]) {
                    a.add(arr1[i]);
                }
            }
        }
        System.out.println(a);
    }


    public void OccuranceOfEachElement() {
        int[] arr = {10, 20, 14, 15, 31, 47, 15, 10, 14, 31};
        HashMap<Integer, Integer> test = new HashMap<>();
        int count = 1;

        for (int i = 0; i < arr.length - 1; i++) {
            if (test.containsKey(arr[i])) {
                test.put(Integer.valueOf(arr[i]), test.get(arr[i]) + 1);
            } else {
                test.put(arr[i], count);
            }


        }
        System.out.println(test);

    }


    public void ReverseArray()
    {
        int[] arr = {10,51,47,12};
        int[] rev = new int[arr.length];

        for (int i = 0; i < arr.length; i++) {
            rev[i] = arr[arr.length - 1 - i];
        }

        System.out.println(Arrays.toString(rev));

   }




}
