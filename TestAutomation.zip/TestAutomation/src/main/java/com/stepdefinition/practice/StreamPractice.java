package com.stepdefinition.practice;

import com.stepdefinition.Test.Person;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class StreamPractice {

    //check for even and then take the square root
    public void CheckEvenAndGetSquareRoot()
    {
        List<Integer> a = Arrays.asList(10,49,25,45,74,15,41,75,48,74,15);

        //check for even number
        //ensure greater than >5
        //instersed in only 3
        //findsquare and add 2 to that
        //print all

        a.stream()
                .filter(b -> b%2 == 0 && b>5)
                .filter(b -> b>5)
                .limit(5)
                .map(b -> b*b)
                .map(b->b + 2)
                .forEach(System.out::println);


    }


    //Find the sum of number
    public void SumOfNumber()
    {
        List<Integer> test = Arrays.asList(10,24,65,12);
        test.stream()
                .reduce( (a,b) -> {
                    return a+b;
                });




    }
















    //a list of strings to uppercase and lowercase
    public void ConverData()
    {
        List<String> a  = Arrays.asList("Sowmya", "Srikant","Ankegowda");

        a.stream().filter(s -> Boolean.parseBoolean(s.toLowerCase())).forEach(System.out :: println);
    }

// Find the longest string in a list of strings using Java streams:
    public void LongestString()
    {

        List<String> list = Arrays.asList("Sowmya","Srikanth","Vijay","Yashana","Karna","Viraj");

        list.stream()
                .filter(a -> a.length()>7)
                .forEach(System.out :: println);


    }

    //Calculate the average age of a list of Person objects

    public void AverageAge()
    {
        List<Person> persons = Arrays.asList(
                new Person("Alice", 25),
                new Person("Bob", 30),
                new Person("Charlie", 35)
        );

        double age = persons.stream()
                .mapToInt(Person :: getAge)
                .average()
                .orElse(0);

        System.out.println(age);


    }

    //Check if a list of integers contains a prime number using Java streams:
    public void CheckPrimeNumbe()
    {
        List<Integer> numbers = Arrays.asList(2, 4, 6, 8, 10, 11, 12, 13, 14, 15);
        List<Integer> a = numbers.stream()
                .filter(this::isPrim)
                        .collect(Collectors.toList());
        System.out.println("List contains a prime number: " + a);

  }
  public void smallestElement()
  {
      List<Integer> numbers = Arrays.asList(2, 4, 6, 8, 10, 11, 12, 13, 14, 15);






  }




    public boolean isPrim(int number)
    {
        if (number <= 1) {
            return false;
        }
        if (number == 2) {
            return true;
        }
        if (number % 2 == 0) {
            return false;
        }
        for (int i = 3; i <= Math.sqrt(number); i += 2) {
            if (number % i == 0) {
                return false;
            }
        }

        return false;
    }



}
