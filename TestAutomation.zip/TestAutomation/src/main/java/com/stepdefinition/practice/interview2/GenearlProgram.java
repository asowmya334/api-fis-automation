package com.stepdefinition.practice.interview2;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class GenearlProgram {

 public void ReverseString()
 {
     String a = "Sowmya";
     String rev = "";
     char[] c = a.toCharArray();

     for(int i = 0 ; i <= a.length() -1 ; i++)
     {
         rev = a.charAt(i) + rev;
     }

     System.out.println(rev);
 }

 public void ReverseWord()
 {
     String a = "This is the program";
     String rev = "";
     String[] b = a.split(" ");

     for(int i = 0 ; i<= b.length -1  ; i++ )
     {
         rev = b[i] + rev ;


     }

     System.out.println(rev);


 }

 public void  PrimeNumber()
 {
     int num = 15;
     boolean flag = true;

     for(int i = 2 ; i < num ; i++ )
     {
         if(num % i == 0)
         {
             flag = false;
         }

     }

     if(flag == false)
     {
         System.out.println("Not a prime");
     }
     else {
         System.out.println("It is prime");
     }



 }

public void OddEVEN()
{
    List<Integer>  number = Arrays.asList(12,9,10);

    List<Integer> even = number.stream()
            .filter(i -> i% 2 ==0)
            .collect(Collectors.toList());

    List<Integer> odd = number.stream()
            .filter(i -> i% 2 !=0)
            .collect(Collectors.toList());

    System.out.println(even);
    System.out.println(odd);




}




}
