package com.stepdefinition.practice;

import java.util.Arrays;
import java.util.HashMap;

public class TestPractice {

    //String reverse the string
    public void ReverseString() {
        String a = "This is java program";
        char b[] = a.toCharArray();
        String rev = "";

        for (int i = a.length() - 1; i >= 0; i--) {

            rev = rev + a.charAt(i);
        }

        System.out.println(rev + "Reverse the string");
    }

    public void ReverseUsingArray() {
        int a[] = new int[]{55, 15, 1, 2};
        int[] rev = new int[a.length];
        int end = a.length - 1;
        int temp = 0;


        for (int i = 0; i < a.length; i++) {
            rev[i] = a[end - i];
        }
        System.out.println(Arrays.toString(rev));

        int start = 0;

        while (start < end) {
            temp = a[start];
            a[start] = a[end];
            a[end] = temp;

            start++;
            end--;

        }

        System.out.println(Arrays.toString(a));


    }

    public void CheckPrime() {
        int num = 10;
        boolean fag = false;

        for (int i = 2; i <= num - 1; i++) {
            if (num % i == 0) {
                fag = true;

            }
        }
    }

    public void FirstHighestInAnArray() {
        int a[] = {50, 12, 47, 94, 56, 36, 74};
        int largest = 0;

        for (int i = 0; i < a.length; i++) {
            if (a[i] > largest)
                largest = a[i];

        }

        System.out.println(largest);
    }

    public void SecondLargest() {
        int b[] = {55, 45, 78, 95, 14, 77};
        int largest = 0;
        int secondlargest = b[0];

        for (int i = 0; i <= b.length - 1; i++) {
            if (b[i] > largest) {
                secondlargest = largest;
                largest = b[i];


            } else if (b[i] != largest && b[i] > secondlargest) {
                secondlargest = b[i];
            }


        }
        System.out.println("first largest" + largest);
        System.out.println("second  largest" + secondlargest);


    }


    public void secondLargest2() {
        int[] num = {100, 150, 33, 14, 45, 12};
        int largest = 0;
        int secondLargest = num[0];

        for (int i = 0; i < num.length - 1; i++) {
            if (num[i] > largest) {
                secondLargest = largest;
                largest = num[i];
            } else if (num[i] != largest && num[i] > secondLargest) {
                secondLargest = num[i];
            }
        }

        System.out.println("first largest" + largest);
        System.out.println("second  largest" + secondLargest);


    }

    public void SwapTwoNumberWithOutAdditionVarialbe() {
        int a = 900;
        int b = 300;

        System.out.println(String.format("Before sort %s, %s", a, b));
        a = a - b;
        b = b + a;
        a = b - a;
        System.out.println(String.format("After sort %s , %s", a, b));

    }

    public void Anagram() {
        String a = "silent";
        String b = "listen";
        //char[] c = a.toCharArray();
        boolean flag = true;


        for (int i = 0; i < a.length() - 1; i++) {
            String c = String.valueOf(a.charAt(i));
            if (b.contains(c) != true) {
                flag = false;

            }


        }

        if (flag == false) {
            System.out.println("not a Anagram");
        }


    }

    public void RemoveDuplicates() {
        String a = "stringsin";
        char c[] = a.toCharArray();
        StringBuilder b = new StringBuilder();

        for (char m : c) {
            if (b.indexOf(String.valueOf(m)) == -1) {
                b.append(m);
            }


        }

        System.out.println(b);

    }

    public void FindDuplicate() {
        String a = "this is a sting";
        HashMap<String, Integer> test = new HashMap<>();
        int count = 0;

        for (char c : a.toCharArray()) {
            String s = String.valueOf(c);
            if (test.containsKey(s)) {

                test.put(s, test.get(s) + 1);
            } else {
                test.put(s, 1);
            }

        }

        System.out.println(test);
    }

    public void EvenOrODD() {
        int numb = 100;

        if (100 % 2 == 0) {
            System.out.println("it is  a even");
        } else {
            System.out.println("it is a odd");
        }


    }

    // Sum of two. Write a method that accepts an int[] array and an int number, and find 2 elements in the array that sum is equal to the given int. Assume that an input array will have only one pair of numbers that sum equal to our given number. It will always have this pair. See input and output examples. I use the Brute Force algorithm.

    public void SumOfTwo() {
        int[] a = {1, 2, 3, 4};
        int num = 4;
        int sum = 0;
        int len = a.length - 1;

        for (int i = 0; i <= 3; i++) {
            for (int j = i + 1; j <= 3; j++) {
                if (a[i] != a[j]) {
                    sum = a[i] + a[j];
                    if (sum == num) {
                        System.out.println(sum);
                        System.out.println(a[i]);
                        System.out.println(a[j]);

                    }
                }
            }

        }


    }

    public void SortArray() {
        int[] a = {10, 30, 20, 70, 15};


        for (int i = 0; i < a.length - 1; i++) {
            for (int j = 0 ; j < a.length - i - 1; j++) {
                if (a[j] > a[j +1 ]) {
                    int temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;


                }

            }

        }
        // Print the sorted array
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }

    }

    public void SortArray1() {
        int[] a = {10, 30, 20, 70, 15};
        int temp = 0;

        for (int i = 0; i < a.length - 1; i++) {
            for (int j = 0; j < a.length - i - 1; j++) {
                if (a[j] > a[j + 1]) {
                    // Swap a[j] and a[j + 1]
                    temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                }
            }
        }

        // Print the sorted array
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }

    public void VowelOrNot()
    {
       String a = "Hello";

       a.toLowerCase().matches(".*[aeiou].*");





    }


}
