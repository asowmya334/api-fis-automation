package com.stepdefinition.practice;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class classecample {

    public void SecondFrequemtCharacter()
    {
        String a = "DevLabsAlliance";
        HashMap<String , Integer> test =  new HashMap<>();
        int count = 1;

        for (char ss: a.toCharArray()) {
            String b = String.valueOf(ss).toLowerCase();
            if(test.containsKey(b))
            {
                count = test.get(b) + 1;

                test.put(b,count);
            }
            else {
                test.put(String.valueOf(ss),count);
            }
        }

        System.out.println(test);
        int firstlargest = 0;
        int secondLargest = 0;

        String firstkey = "" ;
        String  secondKey = "";

        for (Map.Entry<String , Integer> test1: test.entrySet()) {

            int cc = test1.getValue();
            if( cc > firstlargest)
            {
                secondLargest = firstlargest;
                secondKey = firstkey;
                firstlargest = cc;
                firstkey = test1.getKey();

            }
            else if(cc != firstlargest && cc > secondLargest)
            {
                secondLargest = cc;
                secondKey = test1.getKey();
            }


        }

        System.out.println(secondKey);
        System.out.println(secondLargest);












    }













}


