package com.stepdefinition;

public class Response {
    private Response res ;


}
