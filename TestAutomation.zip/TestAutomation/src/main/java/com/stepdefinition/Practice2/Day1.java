package com.stepdefinition.Practice2;

import org.testng.Assert;

import java.util.*;
import java.util.stream.Collectors;

public class Day1 {

    public void callMethodDay1() {
        SumOfElement();

    }

    public void SumOfElement()
    {
        int[] a = {10,15,24,65,95};
        int sum = 0 ;
        int num1 = a[0];

        for(int i = 0 ; i< a.length -1 ;i++)
        {
            sum = sum + i;


        }
        System.out.println(sum);


    }

    public void CheckTwoArrays()
    {
        int[] a = {10,15,24,65,95};
        int[] b = {15,24,95,10,65};

        Arrays.sort(a);
        Arrays.sort(b);

        Assert.assertEquals(a,b);







    }





    //Write a Java Program to find the duplicate characters in a string

    public void DuplicateCharacters()
    {
        String a = "asowmya";
        int count = 1;
        Set<String> mm = new HashSet<>();

        System.out.println("this is the string");
        a.chars().mapToObj(s -> (char) s).filter(s -> mm.add(String.valueOf(s))).forEach(System.out::println);





        HashMap<String, Integer> test =  new HashMap<>();

        for(int i = 0 ;i< a.length() ; i++)
        {
            String c = String.valueOf(a.charAt(i));
            if(test.containsKey(c))
            {
                count = test.get(c) + 1;
                test.put(c ,count);
            }
            else
            {
                test.put(c,count);
            }


        }

        System.out.println(test);
        for (Map.Entry<String,Integer> tt : test.entrySet()) {
            if(tt.getValue() > 1)
            {
                System.out.println(tt.getKey());
            }

        }







    }




    //Write a Java Program to find the duplicate characters in a string.

    public void SecondHighest()
    {
        int[] arr = {10,25,64,18,96,65};
        int firstLargest = arr[1];
        int secondLargest = arr[1];

        for(int i = 0 ; i < arr.length ; i ++)
        {
            if(arr[i] > firstLargest)
            {
                secondLargest = firstLargest;
                firstLargest = arr[i];
            } else if (arr[i] > secondLargest && arr[i] !=  firstLargest ) {
                secondLargest = arr[i];

            }

        }

        System.out.println(firstLargest);
        System.out.println(secondLargest);

    }













    //Write a Java Program for the Fibonacci series.
    public void Fibonnaci()
    {
        int num = 5;
        List<Integer> test = new ArrayList<>();

        int num1 = 0;
        int num2 = 1;
        int num3;

        test.add(num1);
        test.add(num2);
        for(int i = 1 ; i<= num; i++)
        {

           num3 = num1 + num2 ;
           num1 = num2;
           num2 = num3;
           test.add(num3);


        }

        System.out.println(test);


        //forloop

        for (Integer b : test) {

            System.out.println(b);

        }

        Iterator<Integer> tt = test.iterator();

        while (tt.hasNext())
        {
            System.out.println(tt.next());
        }




    }







    public void Palidrome()
    {
        String a = "sowmya";
        String rev = "";

        for(int i = 0 ; i <a.length();i++)
        {
            String c = String.valueOf(a.charAt(i));
            rev = c + rev;

        }

        if(a == rev)
        {
            System.out.println("this is pallidrome");
        }
        else
            System.out.println("this is not pallidrome");




    }





    public void PrimeOrNot()
    {
        int num = 15;
        boolean flag = true;

        for(int i = 2 ; i < num ; i++ )
        {
            if(num % i == 0)
            {
                flag = false;
            }


        }

        if(flag == true)
        {
            System.out.println("Not a prime");
        }
        else {
            System.out.println("This is a prime");
        }
    }

    //Java Program to iterate HashMap using While and advance for loop.
    public void iterateHashMap()
    {
        HashMap<String,Integer> test =  new HashMap<>();
        test.put("red" , 101);
        test.put("Organge" , 102);
        test.put("black" , 103);
        test.put("green" , 104);


        Iterator<Map.Entry<String,Integer>> it = test.entrySet().iterator();

        while(it.hasNext())
        {
            System.out.println(it.next());
        }




    }






    // a Java Program to count the number of words in a string using HashMap.

    public void NumberOfWorkds()
    {

        String a = "this is java";
        HashMap<String , Integer> test =  new HashMap<>();

        String[] c = a.split("");

        for (String d : c) {
            int e = d.length();
            test.put(d , e);

        }

        System.out.println(test.size());


    }






    public void SwapNumber()
    {
        int a = 100;
        int b = 200;
        int temp;

        temp = a;
        a = b;
        b = temp;

        System.out.println(a);
        System.out.println(b);

        a = a+b;
        b = a - b;
        System.out.println(b);
        a = a - b;
        System.out.println(a);



    }



    public void reverseString1()
    {
        String a = "sowmya";
        String rev = "" ;
        for(int i = 0 ; i< a.length() ; i++)
        {
            String c = String.valueOf(a.charAt(i));
            rev = c + rev;
        }
        System.out.println(rev);


    }







    public void CheckPalidrome()
    {
        String a = "bcbc";
       System.out.println(ReverseStrings(a));

       for(int i = 0 ; i< a.length() ; i++)
       {

           System.out.println(a);
           String b = ReverseStrings(a);
           if(a.equalsIgnoreCase(ReverseStrings(a)))
           {
               System.out.println("Pallagrome");

           }else
           {
               String e = String.valueOf(a.charAt(i));
              a =  a.substring(i+1);

           }
       }





    }
    public String ReverseStrings(String a)
    {
        String rev = "";

        for(int i = 0 ; i < a.length() ; i ++)
        {
            rev = a.charAt(i) + rev;

        }
        return rev;


    }









    public void FindMedian()
    {

        int[] arr = {10,25,47,12,36};
        int temp ;

        for(int i = 0 ; i  < arr.length ; i++)
        {
            for(int j = i+1 ; j  < arr.length ; j++) {


                if(arr[i] > arr[j])
                {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }

            }

        }

        for(int i = 0 ; i  < arr.length ; i++) {
            System.out.println(arr[i]);
        }

        int mid = arr.length / 2;
        System.out.println(arr[mid]);










    }





    public void Printnumber()
    {
        int num = 10;
        int res3;
        int res5;

        for(int i = 1 ; i <= num ; i++)
        {
            if(i % 3 == 0 && i % 5 == 0)
            {
                System.out.println("fizzBuzz");
            }else if(i % 3 == 0 || i % 5 == 0)
            {
                System.out.println("fizz");
            }else
            {
                System.out.println(i);
            }

        }

    }





    public void StreamsOnNumbers() {
        //Streams - Given a list of integers, find out all the even numbers that exist in the list using Stream functions?

        List<Integer> test = Arrays.asList(10, 25, 47, 10, 95, 14, 36);
        System.out.println("Given a list of integers, find out all the even numbers that exist in the list using Stream functions?");
        test.stream().filter(a -> a % 2 == 0).forEach(System.out::println);

        //Given a list of integers, find out all the numbers starting with 1 using Stream functions?
        System.out.println("Given a list of integers, find out all the numbers starting with 1 using Stream functions?");
        test.stream().map(s -> String.valueOf(s))
                .filter(s -> s.startsWith("1")).forEach(System.out::println);

        //How to find duplicate elements in a given integers list in java using Stream functions?
        System.out.println("How to find duplicate elements in a given integers list in java using Stream functions?");
        Set<Integer> test1 = new HashSet<>();

        test.stream().filter(s -> !test1.add(s)).forEach(System.out::println);
        test.stream().distinct().forEach(s -> System.out.println(s));

        //Given the list of integers, find the first element of the list using Stream functions?
        System.out.println("Given the list of integers, find the first element of the list using Stream functions?");
        System.out.println(test.stream().findFirst());

        //Given a list of integers, find the total number of elements present in the list using Stream functions?
        System.out.println("Given a list of integers, find the total number of elements present in the list using Stream functions?");
        System.out.println(test.stream().count());

        //Given a list of integers, find the maximum value element present in it using Stream functions?
        System.out.println("Given a list of integers, find the maximum value element present in it using Stream functions?");
        System.out.println(test.stream().max(Integer::compare).get());


        //Given a list of integers, sort all the values present in it using Stream functions?
        test.stream().sorted().forEach(System.out::println);

        //Given a list of integers, sort all the values present in it in descending order using Stream functions?

        test.stream().sorted(Collections.reverseOrder()).forEach(System.out::println);

    }

        public void StreamsOnString() {
            String input = "Java articles are Awesome";

            //Given a String, find the first non-repeated character in it using Stream functions?
            System.out.println("Given a String, find the first non-repeated character in it using Stream functions?");

            System.out.println(input.chars().mapToObj(s -> (char) s)
                    .filter(s -> input.indexOf(s) == input.lastIndexOf(s))
                    .findFirst());

            //Given a String, find the first repeated character in it using Stream functions?
            Set<Character> test = new HashSet<>();
            System.out.println(input.chars().mapToObj(s -> (char) s).
                    filter(s -> !test.add(s)).findFirst());

        }


    public void SubArrayNum() {
        int num = 15;
        int[] t = {10, 25, 3, 2};
        int sum = 0;
        int start = 0;

        for (int end = 0; end < t.length - 1; end++) {
            sum = sum + t[end];

            while (sum > num && start <= end) {
                sum = sum - t[start];
                start++;

            }
            if (sum == num && (end - start + 1) > 1) {
                for (int i = start; i <= end; i++) {
                    System.out.print(t[i] + (i < end ? ", " : ""));
                }
            }


        }


    }


    public void checkPrimeOrNot() {
        int num = 15;
        boolean flag = true;

        for (int i = 2; i < num - 1; i++) {
            if (num % i == 0) {
                flag = false;
            }
        }

        if (flag == true) {
            System.out.println("Not a prime");
        } else {
            System.out.println("It is a prime");
        }


    }


    public void FindDuplicateElement() {

        String a = "asowmya";
        Set<String> b = new HashSet<>();
        List<String> e = new ArrayList<>();

        for (Character c : a.toCharArray()) {
            if (!b.contains(c.toString())) {
                b.add(c.toString());
            }
        }
        e = b.stream().sorted().collect(Collectors.toList());
        System.out.println(e);
    }


    //Reverse the string
    public void ReverseString() {
        String b = "Sowmya";
        char[] c = b.toCharArray();
        String rev = "";

        for (char n : c) {
            rev = n + rev;

        }

        System.out.println(rev);
    }

    //count the occurance of a string
    public void OccurOfString() {
        String b = "Occurence Of String";
        HashMap<String, Integer> test = new HashMap<>();
        int count = 1;
        for (int i = 0; i < b.length(); i++) {
            String g = String.valueOf(b.charAt(i));
            if (test.containsKey(g)) {
                count = test.get(g) + 1;
                test.put(g, count);
            } else {
                test.put(g, count);
            }
        }
        System.out.println(test);

    }

    //sort the Arrayu

    public void SortArray() {
        int[] a = {10, 20, 45, 13, 15, 12};
        int temp;

        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[i] > a[j]) {
                    temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }

            }

        }

        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
    }

    public void IntersectTwoArray() {
        int[] a = {10, 25, 41, 35, 45, 62};
        int[] b = {15, 14, 75, 10, 25, 12, 36};

        int[] interSection = new int[a.length - 1];


        for (int i = 0; i < a.length - 1; i++) {
            for (int j = 0; j < b.length - 1; j++) {
                if (a[i] == b[j]) {

                    interSection[i] = a[i];
                }


            }
        }

        for (int i = 0; i < interSection.length - 1; i++) {
            System.out.println(interSection[i]);
        }

    }

}
