let marks = new Array(6);
let marks1 = new Array(10,23,96,85,45,78);
marks = [15,85,96,34,78];

for(let i = 0 ; i < marks1.length ; i++)
{

console.log(marks1[i])

}

//to add and increse and add the element in array
marks1.push(100);

console.log(marks1);
marks1.unshift(120);
marks1.pop()//delets the last element in the array
console.log(marks1);
marks1.indexOf(5)
console.log(marks1);
marks1.includes(85);
console.log(marks1.includes(85));
let test = marks.slice(2,5);
console.log(test);

//Map , reduce ,filter //sort

let fruits = ["chiku","bannana","cherry","apple","gauva"];

console.log(fruits.sort())
console.log(fruits.reverse())

//sort is case sensitive based on the  case it sort Capatical comes first and small letterv

var scores = [100, 0o5 ,96,78,96,48]
console.log(scores.sort())

//sort does not work for numbers it works for only alphatbet 
//follow below appproach for sorting


console.log(scores.sort((a,b) => a-b ))     //normal order 
console.log(scores.sort((a,b )=> b-a))      //reverse order 