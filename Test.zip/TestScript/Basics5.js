function add(a,b)
{
    
console.log(a+b)

    return a+b;
        
}

let x = add(2,4)
console.log(x)
console.log(add(2,4))

//Anyonyms function , this repesent => 

let a = function(d,e)
{
    return d+e 
}

let sumOfFunciotn = (c,d) => c+d

//Stirng Functions 

let day = "Sowmya"
console.log(day.length);
console.log(day[1])
console.log(day[2])
console.log(day[5])

let dd = "sowmya ankegowda"
let cc = dd.split(" ")
console.log(cc[1])

//reverse a string
var  aa = "Sowmya";
console.log(aa.split('').reverse().join(''))
console.log(aa.split('').reverse().join(''))
console.log(aa.split('').reverse().join(''))

let rev = "";

for (let i = 0; i < aa.length ; i++) { // Loop from the end to the beginning
    rev += aa[i]; // Concatenate characters to rev
}

console.log(rev); 
console.log(rev);
