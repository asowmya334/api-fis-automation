console.log("this is my name");

//declaring variable
//var ,let ,const

let a = 5;
console.log(a);
console.log(typeof(a));