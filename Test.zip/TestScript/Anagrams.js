//Anagrams
//Program to find if the two strings are Anagrams.
//Input : listen and silent
//Output : True

var a = "listen";
var b = a.split('').reverse().join('');

if(a === b)
{
    console.log("True")
}
console.log("False")


//Find the Second Smallest in an Array
//Input : [7,5,6,1,4,2]
//Output : 2

var arr1 = [7,5,6,1,4,2];
var firstLargest = arr1[0];
var secondLargest = 0;

for(let i = 0 ; i < arr1.length ; i++)
{
    if(arr1[i] > firstLargest)
    {
        secondLargest = firstLargest;
        firstLargest = arr1[i];
    }
    else if(arr1[i] != firstLargest && arr1[i] > secondLargest)
    {
        secondLargest = arr1[i];
    }
}

console.log(secondLargest);


// //Count Occurrence of a Character in a String
// Input String: “programming”
// Output : p -1 , m -2


var String1 = "programming";
function charCount(str)
{

    const charString = {};
    for(var a of str)
    {
        if(charString[a])
        {
            charString[a]++;
        }
        else{
            charString[a] = 1;
        }
    }
return charString;

}

const inputString = "programming";
const result = charCount(inputString);

console.log(result);


//Objects 
let user = {};

//// set
user["likes birds"] = true;

// get
//alert(user["likes birds"]); // true

// delete
//delete user["likes birds"];

console.log("sowmya")
var b = "Sowmya";
let test = {};

for(let k in b)
{
    if(test[k])
    {
        test[k]++
    }
    else{
       test[k] = 1
    }
}

//find the occurance 


let c1 = "Sowmya ankegowda";
let d1 = {}

for(let e1 of c1)
{
    if(d1[e1])
    {
        d1[e1]++;
    }else{
        d1[e1] = 1
    }
}

console.log(d1);


let li = "Sweet"
let tt = {}

for(let nn of li)
{
    if(tt[nn])
    {
        tt[nn]++
    }
    else{
        tt[nn] = 1
    }
}

console.log(tt)

//Reverse Each Word in a String
//Input :”Hello World”
//Output : “olleH dlroW”


let z = "sowmya"
let zz = z.split('').reverse().join('')
console.log(zz)