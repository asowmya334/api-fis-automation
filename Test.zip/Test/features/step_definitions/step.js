const assert = require('assert');
const { Given, When, Then } = require('@cucumber/cucumber');
const {test, expect,playwright} = require('@playwright/test');
const { LoginPages } = require('../PageObject/LoginPages');
const { ActionBoard } = require('../PageObject/ActionBoard');
const { CartPage } = require('../PageObject/CartPage');

Given('Loggin to the product {string} and {string}', async function (email, password) {

    const browser = playwright.chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    const loginPage = new LoginPages(page);
    await loginPage.goToLogin(); // Added await
    await loginPage.validlogin(); // Added await

    const actionBoard = new ActionBoard(page);
    await actionBoard.AddToCartMethod();
    await actionBoard.cartButton();

    const cartPage = new CartPage(page);
    await ProductAddded();

    await page.pause();

    // await page.goto("https://rahulshettyacademy.com/client", { timeout: 60000 });
    // await page.getByPlaceholder("email@example.com").fill(email);
    // await page.getByPlaceholder("enter your passsword").fill(password);
    // await page.getByRole("button", { name: "login" }).click();
});