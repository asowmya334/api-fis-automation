class CartPage{

constructor(page)
{
    this.page = page;
    this.itemAdded = page.locator("div li");
    this.checkProductAdded = page.locator("h3:has-text('ZARA COAT 3')");
    




}

async ProductAddded()
{
    await this.itemAdded.first().waitFor();
    const test = await  this.checkProductAdded.isVisible();
    expect(test).toBeTruthy();

}
 
      


}
module.exports = { CartPage };