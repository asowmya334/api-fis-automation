class LoginPages {
    constructor(page) {
        this.page = page;
        this.emailUserName = page.getByPlaceholder("email@example.com");
        this.password = page.getByPlaceholder("enter your passsword"); // Corrected typo
        this.login = page.getByRole("button", { name: "login" });
    }

    async goToLogin() {
        await this.page.goto("https://rahulshettyacademy.com/client", { timeout: 60000 });
    }

    async validlogin() {
        await this.emailUserName.fill("sowmya122@gmail.com");
        await this.password.fill("Banglore@123");
        await this.login.click();
    }
}

module.exports = { LoginPages };