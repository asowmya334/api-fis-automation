class ActionBoard{

    constructor(page)
    {
        this.page = page;
        this.addToChart = page.locator(".card-body").filter({hasText:"ZARA COAT 3"}).getByRole("button", {name:"Add To Cart"});
        this.cartButton = page.locator('[routerlink="/dashboard/cart"]');
    }

    async AddToCartMethod()
    {
        await this.addToChart.click();
    }

    async ClicOnCartButton()
    {
        await this.cartButton.click();
    }


}


module.exports = { ActionBoard };