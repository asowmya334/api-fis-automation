const {test, expect} = require('@playwright/test')

test('differntlocators' , async({page}) => {

await page.goto("https://rahulshettyacademy.com/angularpractice/",{timeout: 60000})

await page.getByPlaceholder("Password").fill("sowmya");
await page.getByLabel("Check me out if you Love IceCreams!").check();
await page.getByLabel("Gender").selectOption("Male");
await page.getByRole("button", {name : 'Submit'}).click();


});

test.only('Login using credentials play' , async({page}) =>
    {

      
        await page.goto("https://rahulshettyacademy.com/client",{timeout : 60000})
        await page.getByPlaceholder("email@example.com").fill("sowmya122@gmail.com");
        await page.getByPlaceholder("enter your passsword").fill("Banglore@123");
        await page.getByRole("button" , {name:"login"}).click();

    
        //await page.waitForLoadState('networkidle');
        await page.locator('.card-body h5 b').first().waitFor();
        await page.locator(".card-body").filter({hasText:"ZARA COAT 3"}).getByRole("button", {name:"Add To Cart"}).click();







        //const tt = await page.locator('.card-body h5 b').allTextContents();
        //console.log(tt);
       // console.log(await page.locator('.card-body h5 b').first().textContent())
        //await expect(page.locator('.card-body h5 b').first()).toContainText("ZARA COAT 3")
    
        //select the product ZARA coat
      
        // const tt1 = page.locator(".card-body");
        // const count1 = await tt1.count();
        // for(let i = 0 ; i < count1 ; i++)
        // {
        //     if(await tt1.nth(i).locator("b").textContent() == "ZARA COAT 3");
        //     {
        //        await tt1.nth(i).locator("text=  Add To Cart").click();
        //         break;
        //     }
        // }
         
    
         await page.locator('[routerlink="/dashboard/cart"]').click();
    
         //check the itmes is added from previous step
    
    
        await page.locator("div li").first().waitFor();
        const test = await page.locator("h3:has-text('ZARA COAT 3')").isVisible();
        expect(test).toBeTruthy();
    
        
        await page.locator("button:has-text('Checkout')").click();

        //checkout page
    
        await page.locator('[placeholder="Select Country"]').pressSequentially("ind",{delay: 1000})
    
    
        const country = page.locator('[class="ta-results list-group ng-star-inserted"]');
        await country.waitFor();
        const totalCou = await country.locator("button").count();
    
        for(let i = 0 ; i < totalCou ; i++)
        {
            const text = await country.locator("button").nth(i).textContent();
            console.log(text);
           if(text === " India")
           {
            await country.locator("button").nth(i).click();
            break;
           }
        }
    
        await expect(page.locator('.user__name [type="text"]').first()).toHaveText("sowmya122@gmail.com");
    
        await page.locator('[class="btnn action__submit ng-star-inserted"]').click();
    
    
        //const sucessMess = await page.locator('[class="hero-primary"]');
        await expect(page.locator('[class="hero-primary"]')).toHaveText(" Thankyou for the order. ");
    
    
        const ta = await page.locator(".em-spacer-1 .ng-star-inserted").textContent();
        console.log(ta);
    
    
        //check the order in order page
    
        await page.locator('button[routerlink="/dashboard/myorders"]').click();
    
        //To validate data table 
        await page.locator("tbody").waitFor();
        const rows = await page.locator("tbody tr")
    
        for(let i = 0 ; i < await rows.count() ; ++i)
        {
    
          const a = await rows.nth(i).locator("th").textContent();
          if(  ta.includes(a))
          {
            await rows.locator("button").first().click();
           await console.log("orderid exisitns");
            break;
          }
    
        }

    
    });
    