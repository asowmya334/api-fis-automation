const { test, expect } = require('@playwright/test');
const { LoginPages } = require('../PageObject/LoginPages');
const { ActionBoard } = require('../PageObject/ActionBoard');
const { CartPage } = require('../PageObject/CartPage');

test.only('Login using credentials play', async ({ page }) => {
    const loginPage = new LoginPages(page);
    await loginPage.goToLogin(); // Added await
    await loginPage.validlogin(); // Added await

    const actionBoard = new ActionBoard(page);
    await actionBoard.AddToCartMethod();
    await actionBoard.cartButton();

    const cartPage = new CartPage(page);
    await ProductAddded();

    await page.pause();

});