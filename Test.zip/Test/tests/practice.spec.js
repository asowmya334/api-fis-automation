const {test, expect} = require('@playwright/test')

test('Test1',async({browser}) =>
{

    const context = await browser.newContext();
    const page = await context.newPage();
    await page.goto("https://www.amazon.in/", { timeout: 60000 });


});

test('Test2',async({page}) =>
{
    await page.goto("https://www.ebay.com/",{ timeout: 60000 });
    console.log(await page.title());
    await expect(page).toHaveTitle("Electronics, Cars, Fashion, Collectibles & More | eBay");
    await page.locator("[title='Search']").click();
    await page.locator("[title='Search']").fill("Book",{ timeout: 60000 });
    await page.locator('#gh-search-btn').click();
    await page.waitForSelector('.s-item')

    const firstItem = await page.$$('.s-item');
    if(firstItem.length >= 3)
    {
        await firstItem[2].click();
    }else
    {
        console.log("No items found")
    }
});

test('Test On textbox' , async({page}) =>
{
    const name = "sowmya";
    const email = "sowmya.ankegowda@text.com";
    const currentAdd = "Bangalore Karnataka";
    const permanentAddress = "Bangalore Karnataka";
    await page.goto("https://demoqa.com/text-box", { timeout: 120000 });
    await page.locator('#userName').fill(name);
    await page.locator('#userEmail').fill(email);
    await page.locator('#currentAddress',{ timeout: 120000 }).fill(currentAdd);
    await page.locator('#permanentAddress',{ timeout: 120000 }).fill(permanentAddress);
    await page.locator('#submit').click();

    const nameText = await page.locator('#name').textContent();
    const emailText = await page.locator('#email').textContent();
    const currentAddressText = await page.locator('p#currentAddress').textContent();
    const permanentAddressText = await page.locator('p#permanentAddress').textContent();
  
    console.log(nameText);
    console.log(emailText);
    console.log(currentAddressText);
    console.log(permanentAddressText);

    await expect(page.locator('#name')).toContainText('Name:sowmya');
    await expect(page.locator('#email')).toContainText("Email:sowmya.ankegowda@text.com");
    await expect(page.locator('p#currentAddress')).toContainText("Current Address :Bangalore Karnataka ");
    await expect(page.locator('p#permanentAddress')).toContainText("Permananet Address :Bangalore Karnataka ");


});

test("Rahul Sheety page" , async({page}) =>
{

    await page.goto("https://rahulshettyacademy.com/client",{timeout : 60000})
    const register = page.locator('.login-wrapper-footer-text');
    const firstName = page.locator('#firstName');
    const lastName = page.locator('#lastName');
    const email = page.locator('#userEmail');
    const phonenumber = page.locator('#userMobile');
    const occupation = page.locator("[formcontrolname='occupation']");
    const genderMale = page.locator("[value='Male']");
    const genderFemale = page.locator("[value='Female']");
    const password = page.locator('#userPassword');
    const confirmPassword = page.locator('#confirmPassword');
    const consent = page.locator("[type = 'checkbox']");
    const registerButton = page.locator('#login');

    await register.click();
    await firstName.fill("Sowmya");
    await lastName.fill("abc");
    await email.fill("sowmya122@gmail.com");
    await phonenumber.fill('9863214598');
    await occupation.selectOption("Doctor")
    await genderMale.check();
    await password.fill("Banglore@123");
    await confirmPassword.fill("Banglore@123");
    await consent.check();
    await registerButton.click();
    
    const scussfullMessage = await page.locator('.headcolor').textContent();
    console.log(scussfullMessage);
    await expect(page.locator('.headcolor')).toContainText("Account Created Successfully");




});


test.only('Login using credentials' , async({page}) =>
{
    await page.goto("https://rahulshettyacademy.com/client",{timeout : 60000})
    const userEmail = page.locator('#userEmail');
    const password = page.locator('#userPassword');
    const login = page.locator('#login');

    await userEmail.fill("sowmya122@gmail.com");
    await password.fill("Banglore@123");
    await login.click();


    //await page.waitForLoadState('networkidle');
    await page.locator('.card-body h5 b').first().waitFor();
    const tt = await page.locator('.card-body h5 b').allTextContents();
    console.log(tt);
    console.log(await page.locator('.card-body h5 b').first().textContent())
    await expect(page.locator('.card-body h5 b').first()).toContainText("ZARA COAT 3")

    //select the product ZARA coat
  
    const tt1 = page.locator(".card-body");
    const count1 = await tt1.count();
    for(let i = 0 ; i < count1 ; i++)
    {
        if(await tt1.nth(i).locator("b").textContent() == "ZARA COAT 3");
        {
           await tt1.nth(i).locator("text=  Add To Cart").click();
            break;
        }
    }
     

     await page.locator('[routerlink="/dashboard/cart"]').click();

     //check the itmes is added from previous step


    await page.locator("div li").first().waitFor();
    const test = await page.locator("h3:has-text('ZARA COAT 3')").isVisible();
    expect(test).toBeTruthy();

    
    await page.locator("button:has-text('Checkout')").click();

    await page.locator('[placeholder="Select Country"]').pressSequentially("ind",{delay: 1000})


    const country = page.locator('[class="ta-results list-group ng-star-inserted"]');
    await country.waitFor();
    const totalCou = await country.locator("button").count();

    for(let i = 0 ; i < totalCou ; i++)
    {
        const text = await country.locator("button").nth(i).textContent();
        console.log(text);
       if(text === " India")
       {
        await country.locator("button").nth(i).click();
        break;
       }
    }

    await expect(page.locator('.user__name [type="text"]').first()).toHaveText("sowmya122@gmail.com");

    await page.locator('[class="btnn action__submit ng-star-inserted"]').click();


    //const sucessMess = await page.locator('[class="hero-primary"]');
    await expect(page.locator('[class="hero-primary"]')).toHaveText(" Thankyou for the order. ");


    const ta = await page.locator(".em-spacer-1 .ng-star-inserted").textContent();
    console.log(ta);


    //check the order in order page

    await page.locator('button[routerlink="/dashboard/myorders"]').click();

    //To validate data table 
    await page.locator("tbody").waitFor();
    const rows = await page.locator("tbody tr")

    for(let i = 0 ; i < await rows.count() ; ++i)
    {

      const a = await rows.nth(i).locator("th").textContent();
      if(  ta.includes(a))
      {
        await rows.locator("button").first().click();
       await console.log("orderid exisitns");
        break;
      }

    }





   


    await page.pause();


});

test('Tiele 6', async({page})=> 
{
    console.log("Sowmya");

    const cart1 = page.locator('[class="cart"]');
    await cart1.first().waitFor();       
    const tts = await cart1.allTextContents();
    console.log(tts.count());
    console.log(tts);
    
    for(let i = 0 ; i < cart1.count() ; i++)
    {
        if(await cart1.nth(i).textContent == "ZARA COAT 3")
        {
            console.log("product added to the cart");
        }
    }
});



